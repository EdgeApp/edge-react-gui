export declare const locales: {
    de: Locale;
    'en-US': Locale;
    'en-GB': Locale;
    es: Locale;
    fr: Locale;
    it: Locale;
    ja: Locale;
    ko: Locale;
    pt: Locale;
    ru: Locale;
    vi: Locale;
    'zh-CN': Locale;
    'zh-TW': Locale;
};
