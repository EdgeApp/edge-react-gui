export interface IntlLocaleType {
    localeIdentifier: string;
    decimalSeparator: string;
    groupingSeparator: string;
}
interface IntlNumberFormatOptionsType {
    toFixed?: number;
    maxDecimals?: number;
    minDecimals?: number;
    noGrouping?: boolean;
}
export declare const EN_US_LOCALE: IntlLocaleType;
export declare const DEFAULT_LOCALE_ID: string;
export declare const SHORT_DATE_FMT: string;
export declare const locale: IntlLocaleType;
/**
 * Formats number input according to user locale
 * Allows decimalSeparator at the end of string
 * @param input {string} - Native style (JS) number
 * @param options
 * @returns {string}
 */
export declare function formatNumberInput(input: string, options?: IntlNumberFormatOptionsType): string;
/**
 * Formats number according to user locale
 * @param number
 * @param options
 * @return {string}
 */
export declare function formatNumber(number: number | string, options?: IntlNumberFormatOptionsType): string;
/**
 * Should have same behaviour as UTILS.isValidInput
 * @param value
 * @returns {boolean}
 */
export declare function isValidInput(value: string): boolean;
/**
 * Should change UTILS.formatNumberInput
 * @param input
 */
export declare function prettifyNumber(input: string): string;
/**
 * Should change UTILS.truncateDecimals
 * @param input
 * @param precision
 * @param allowBlank
 * @returns {string}
 */
export declare function truncateDecimalsPeriod(input: string, precision?: number, allowBlank?: boolean): string;
/**
 * Should change UTILS.truncateDecimals
 * @param input
 * @param precision
 * @param allowBlank
 * @returns {string}
 */
export declare function truncateDecimals(input: string, precision?: number, allowBlank?: boolean): string;
/**
 * Converts internationalized number to Native (JS) presentation
 * @param value
 * @param options
 * @returns {string}
 */
export declare function formatToNativeNumber(value: string, options?: IntlNumberFormatOptionsType): string;
/**
 * Returns date string depending on locale
 */
export declare function formatDate(date: Date, dateFormat?: string): string;
/**
 * Returns h:mm am/pm time string depending on locale
 */
export declare function formatTime(date: Date): string;
/**
 * Returns 'h:mm am/pm, date' string depending on locale.
 */
export declare function formatTimeDate(date: Date, dateFormat?: string): string;
export declare function setIntlLocale(l: IntlLocaleType): void;
export declare function toLocaleDate(date: Date): string;
export declare function toLocaleTime(date: Date): string;
export declare function toLocaleDateTime(date: Date): string;
export declare const trimEnd: (val: string) => string;
/**
 * Return a formatted percent string based on a number or string that is < 1.0
 * and greater than -1.0
 **/
export declare const toPercentString: (percentVal: string | number, opts?: {
    intlOpts?: IntlNumberFormatOptionsType;
    maxPrecision?: number;
    minPrecision?: number;
    plusSign?: boolean;
}) => string;
/** Given a language code, ie 'en_US', 'en-US', 'en-us', 'en'. Pick the language
 * that closest matches
 */
export declare const pickLanguage: (lang: string, languages: string[]) => string | undefined;
/**
 * Picks either a localized string or uses whatever is defined under 'en_US' (or
 * similar tag) as the fallback default string
 */
export declare const getLocaleOrDefaultString: (localizedStrings: {
    [localeId: string]: string;
}) => string | undefined;
export {};
