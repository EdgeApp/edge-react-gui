import { AppConfig } from '../components/publicApi/publicTypes';
export declare const setAppConfig: (appConfig: AppConfig | undefined) => void;
export declare const getAppConfig: () => AppConfig;
