/** @deprecated */
export declare const FONTS: {
    fontFamilyRegular: string;
};
/** @deprecated */
export declare const GRAY_4 = "#F4F5F6";
/** @deprecated */
export declare const WHITE = "#FFFFFF";
