export declare const questionsList: string[];
