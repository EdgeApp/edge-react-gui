import { Theme } from '../../types/Theme';
export declare const edgeDark: Theme;
