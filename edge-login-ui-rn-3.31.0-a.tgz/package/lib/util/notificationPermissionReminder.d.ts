import { NotificationPermissionReminderOptions } from '../components/publicApi/publicTypes';
/**
 * Asks the users for notification permissions, if needed. Returns true if the
 * permissions modal was shown, false if not.
 */
export declare const showNotificationPermissionReminder: (opts: NotificationPermissionReminderOptions) => Promise<boolean>;
