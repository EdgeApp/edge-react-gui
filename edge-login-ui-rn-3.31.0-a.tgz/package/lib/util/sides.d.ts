/**
 * The four sides (top, right, bottom, left) as a tuple.
 */
export type SideList = [number, number, number, number];
export interface Margin {
    marginBottom: number;
    marginLeft: number;
    marginRight: number;
    marginTop: number;
}
export interface Padding {
    paddingBottom: number;
    paddingLeft: number;
    paddingRight: number;
    paddingTop: number;
}
/**
 * Interprets an array of 0-4 numbers as a web CSS sides shorthand
 * (top, right, bottom, left).
 */
export declare function fixSides(sides: number[] | number | undefined, fallback: number): SideList;
export declare function mapSides(sides: SideList, f: (side: number) => number): SideList;
/**
 * Turns a list of sides into CSS margin properties.
 */
export declare function sidesToMargin(sides: SideList): Margin;
/**
 * Turns a list of sides into CSS padding properties.
 */
export declare function sidesToPadding(sides: SideList): Padding;
