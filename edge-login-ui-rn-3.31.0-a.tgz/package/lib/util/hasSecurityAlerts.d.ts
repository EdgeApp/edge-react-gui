import { EdgeAccount } from 'edge-core-js';
type Unsubscribe = () => void;
/**
 * Returns true if the application should show the SecurityAlertsScene.
 */
export declare function hasSecurityAlerts(account: EdgeAccount): boolean;
/**
 * Calls a callback when the account gains or loses security alerts.
 */
export declare function watchSecurityAlerts(account: EdgeAccount, onChange: (hasAlerts: boolean) => void): Unsubscribe;
export {};
