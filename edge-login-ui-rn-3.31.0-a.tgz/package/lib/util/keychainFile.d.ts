import { EdgeAccount, EdgeUserInfo } from 'edge-core-js';
/**
 * A row in the upgraded keychain status file.
 * If a login exists in this file,
 * biometric login is either enabled or disabled.
 * If we haven't made a decision, the login won't be in the file.
 */
export interface KeychainInfo {
    /**
     * The location where the secret is stored, if login is enabled.
     * False if the user has disabled biometric login.
     */
    key: string | false;
    loginId?: string;
    username?: string;
}
/**
 * Looks up a login's status.
 * Returns the location where the secret is stored, false if disabled,
 * or undefined if we have no information about the user.
 */
export declare function getKeychainStatus(file: KeychainInfo[], account: EdgeAccount | EdgeUserInfo): string | false | undefined;
/**
 * Changes a login's status on disk.
 * If a login is enabled, pass the key where the secret is stored.
 * If a login is disabled, pass 'false'.
 * To forget a login, pass `undefined`.
 */
export declare function saveKeychainStatus(file: KeychainInfo[], account: EdgeAccount, status: string | false | undefined): Promise<void>;
/**
 * Reads all saved login statuses from disk.
 */
export declare function readKeychainFile(): Promise<KeychainInfo[]>;
