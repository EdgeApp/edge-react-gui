export interface PeriodicTask {
    start: () => void;
    stop: () => void;
    readonly started: boolean;
}
/**
 * Schedule a repeating task, with the specified gap between runs.
 */
export declare function makePeriodicTask(task: () => Promise<void> | undefined, msGap: number, opts?: {
    onError?: (error: unknown) => void;
}): PeriodicTask;
