export declare const base58: {
    parse(text: string): Uint8Array;
    parseUnsafe(text: string): Uint8Array | undefined;
    stringify(data: Uint8Array | number[]): string;
};
