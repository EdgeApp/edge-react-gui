export declare const toLocalTime: (date: Date) => String;
export declare function snooze(ms: number): Promise<void>;
type AsyncFunction = () => Promise<any>;
export declare function asyncWaterfall(asyncFuncs: AsyncFunction[], timeoutMs?: number): Promise<any>;
export declare const shuffleArray: <T>(array: T[]) => T[];
export declare const validateEmail: (email: string) => RegExpMatchArray | null;
export {};
