export type HapticTriggerType = 'impactLight' | 'impactMedium' | 'impactHeavy';
export declare const triggerHaptic: (type: HapticTriggerType) => void;
