import { EdgeAccount, EdgeAccountOptions, EdgeContext } from 'edge-core-js';
import { OnPerfEvent } from '../components/publicApi/publicTypes';
export type LoginAttempt = {
    type: 'password';
    username: string;
    password: string;
} | {
    type: 'recovery';
    recoveryKey: string;
    username: string;
    answers: string[];
};
export declare function attemptLogin(context: EdgeContext, attempt: LoginAttempt, opts: EdgeAccountOptions, onPerfEvent: OnPerfEvent): Promise<EdgeAccount>;
