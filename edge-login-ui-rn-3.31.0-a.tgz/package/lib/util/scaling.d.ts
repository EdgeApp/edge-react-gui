export declare const scaleH: (size: number, factor?: number) => number;
export declare const scaleV: (size: number, factor?: number) => number;
export { scaleV as scale };
