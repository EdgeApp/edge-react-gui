import type { EdgeAccount } from 'edge-core-js';
/**
 * Check and show the 2fa reminder on login, if necessary.
 */
export declare function showOtpReminder(account: EdgeAccount): Promise<void>;
