import { Action } from '../types/ReduxTypes';
import { LoginParamList } from '../types/routerTypes';
type NamedSceneStates = {
    [Name in keyof LoginParamList]: {
        name: Name;
        params: LoginParamList[Name];
    };
};
/**
 * A union of every possible route state,
 * with its name and matching parameters.
 */
export type SceneState = NamedSceneStates[keyof LoginParamList];
export declare function scene(state: SceneState | undefined, action: Action): SceneState;
export {};
