import { SceneState } from './SceneReducer';
import { TouchState } from './TouchReducer';
export interface RootState {
    createChallengeId: string | null;
    scene: SceneState;
    touch: TouchState;
}
export declare const rootReducer: import("redux").Reducer<RootState>;
