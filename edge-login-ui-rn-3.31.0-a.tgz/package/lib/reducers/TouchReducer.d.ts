import { BiometryType } from '../components/publicApi/publicTypes';
import { Action } from '../types/ReduxActions';
import { KeychainInfo } from '../util/keychainFile';
export interface TouchState {
    readonly touchFile: KeychainInfo[];
    readonly biometryType: BiometryType;
}
export declare const touch: (state: TouchState | undefined, action: Action) => TouchState;
