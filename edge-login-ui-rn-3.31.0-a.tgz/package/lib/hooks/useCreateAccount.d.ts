export declare const useCreateAccountHandler: () => (createAccountParams: {
    username?: string;
    password?: string;
    pin: string;
}) => Promise<import("edge-core-js").EdgeAccount | undefined>;
