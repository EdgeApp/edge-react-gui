import { ViewStyle } from 'react-native';
export interface SpaceProps {
    /**
     * Space props a simple way to give a component space on the sides around
     * the component. You can provide a number to give a specific rem unit of space
     * or a boolean to give the maximum amount of space available relative to its
     * parent component.
     *
     * `top`, `left`, `bottom`, and `right` props are specific sides of the
     * component for which you can assign space. Additionally, `horizontal`,
     * `vertical`, and `around` are a combination of two or more sides. Examples:
     *
     * ```tsx
     * top={1} // 1rem above the component
     * around={2} // 1rem around all sides
     * horizontal={0.5} // 0.5rem on the left and right sides
     * ```
     *
     * Because boolean means to "fill up with maximum space", this allows space
     * props to be used to center and align a component trivially. Examples:
     *
     * ```tsx
     * around={true} // Center vertically and horizontally
     * vertical={true} // Center vertically
     * left={true} // Align to the _right_ (because max space is on the left)
     * ```
     */
    top?: boolean | number;
    right?: boolean | number;
    bottom?: boolean | number;
    left?: boolean | number;
    around?: boolean | number;
    horizontal?: boolean | number;
    vertical?: boolean | number;
    expand?: boolean;
    sideways?: boolean;
}
export type SpaceStyle = Pick<ViewStyle, 'marginTop' | 'marginBottom' | 'marginLeft' | 'marginRight' | 'flex' | 'flexDirection' | 'alignItems' | 'justifyContent'>;
export declare const useSpaceStyle: (props: SpaceProps) => SpaceStyle;
