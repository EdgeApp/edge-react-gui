/**
 * Clears modals when the component unmounts.
 */
export declare function useClearOnUnmount(): void;
