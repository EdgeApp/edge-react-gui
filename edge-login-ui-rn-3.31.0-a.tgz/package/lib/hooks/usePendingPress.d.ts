export type OnPress = () => void | Promise<void>;
/**
 * Creates a `handlePress` function that calls a user-provided `onPress`
 * method and deals with any resulting promises by togging a pending flag
 * and showing errors.
 */
export declare function usePendingPress(onPress?: OnPress): [boolean, () => void];
