export declare function useFilter<T>(allData: T[], filterData?: (filter: string, item: T, index: number) => boolean): [T[], (filter: string) => void];
