import * as React from 'react';
import { ScrollView } from 'react-native';
/**
 * This hook will return a ref, which you can attach to a scroll view.
 * When the `ready` parameter becomes true,
 * we will scroll that view to the bottom.
 */
export declare function useScrollToEnd(ready: boolean): React.MutableRefObject<ScrollView | null>;
