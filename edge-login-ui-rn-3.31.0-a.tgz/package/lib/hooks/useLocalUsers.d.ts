import { EdgeUserInfo } from 'edge-core-js';
import { TouchState } from '../reducers/TouchReducer';
export interface LoginUserInfo extends EdgeUserInfo {
    touchLoginEnabled: boolean;
}
export declare function useLocalUsers(): LoginUserInfo[];
/**
 * Given a list of users from the core,
 * organize the 3 most recent users,
 * followed by the rest in alphabetical order.
 */
export declare function arrangeUsers(localUsers: EdgeUserInfo[]): EdgeUserInfo[];
export declare function upgradeUser(userInfo: EdgeUserInfo, touch: TouchState): LoginUserInfo;
