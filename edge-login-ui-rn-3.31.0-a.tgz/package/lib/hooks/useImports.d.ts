import { Imports } from '../types/ReduxTypes';
/**
 * Grabs various properties passed to the root login component,
 * such as the EdgeContext.
 */
export declare function useImports(): Imports;
