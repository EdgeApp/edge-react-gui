/**
 * IMPORTANT: Changes in this file MUST be synced between edge-react-gui and
 * edge-login-ui-rn!
 */
import { ViewStyle } from 'react-native';
export interface MarginRemProps {
    /** Adds rem to the bottom margin side */
    bottomRem?: number;
    /** Adds rem to the left margin side */
    leftRem?: number;
    /** Adds rem to the right margin side */
    rightRem?: number;
    /** Adds rem to the top margin side */
    topRem?: number;
    /** Adds rem to all margin sides */
    aroundRem?: number;
    /** Adds rem to left and right margin sides */
    horizontalRem?: number;
    /** Adds rem to top and bottom margin sides */
    verticalRem?: number;
}
export type MarginRemStyle = Pick<ViewStyle, 'marginTop' | 'marginBottom' | 'marginLeft' | 'marginRight'>;
export declare const useMarginRemStyle: (props: MarginRemProps) => MarginRemStyle;
