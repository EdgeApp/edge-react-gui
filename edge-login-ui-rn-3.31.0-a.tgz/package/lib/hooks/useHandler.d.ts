/**
 * A better version of `useCallback`.
 *
 * React itself may add this hook in a future version, called `useEvent`.
 * In the meantime, react-native-reanimated has a hook called `useEvent`,
 * so we don't want to conflict with that.
 */
export declare function useHandler<T extends Function>(callback: T): T;
