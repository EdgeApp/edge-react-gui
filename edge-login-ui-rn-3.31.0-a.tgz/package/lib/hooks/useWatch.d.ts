/**
 * Subscribes to changes in a core object's property.
 */
export declare function useWatch<T extends {
    readonly watch: <Name extends keyof T>(name: Name, callback: (value: T[Name]) => void) => () => void;
}, Name extends keyof T>(object: T, name: Name): T[Name];
