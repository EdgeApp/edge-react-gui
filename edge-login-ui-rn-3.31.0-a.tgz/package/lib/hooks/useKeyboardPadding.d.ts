export declare const useKeyboardPadding: () => {
    paddingBottom: number;
};
