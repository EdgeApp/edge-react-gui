import { EdgeAccount, EdgeUserInfo } from 'edge-core-js';
import { BiometryType } from './components/publicApi/publicTypes';
/**
 * Should be called at login to ensure biometric login is properly enabled.
 * @param account The account that has just logged in.
 */
export declare function refreshTouchId(account: EdgeAccount): Promise<void>;
export declare function isTouchEnabled(account: EdgeAccount): Promise<boolean>;
export declare function enableTouchId(account: EdgeAccount): Promise<void>;
export declare function disableTouchId(account: EdgeAccount): Promise<void>;
export declare function getSupportedBiometryType(): Promise<BiometryType>;
/**
 * Looks up the stored biometric secret for a user.
 * Returns undefined if there is no secret, or if the user denies the request.
 */
export declare function getLoginKey(userInfo: EdgeUserInfo, promptString: string, fallbackString: string): Promise<string | undefined>;
