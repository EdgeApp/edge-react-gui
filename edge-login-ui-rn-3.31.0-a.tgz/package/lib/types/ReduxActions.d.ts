import { SceneState } from '../reducers/SceneReducer';
import { TouchState } from '../reducers/TouchReducer';
export type Action = {
    type: 'RESET_APP';
} | {
    type: 'CREATE_CHALLENGE';
    data: string;
} | {
    type: 'NAVIGATE';
    data: SceneState;
} | {
    type: 'SET_TOUCH';
    data: TouchState;
};
