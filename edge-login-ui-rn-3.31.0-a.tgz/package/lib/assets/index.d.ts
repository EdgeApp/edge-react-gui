export declare const LOGO_BIG: any;
export declare const LOGO_SMALL: any;
export declare const PASSWORD_REQ_CHECKED: any;
export declare const PASSWORD_REQ_UNCHECKED: any;
export declare const WELCOME_LOCK: any;
export declare const WELCOME_SHIELD_KEY: any;
