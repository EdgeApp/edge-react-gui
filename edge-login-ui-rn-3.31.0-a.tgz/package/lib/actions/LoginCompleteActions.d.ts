import { EdgeAccount } from 'edge-core-js';
import { Dispatch, GetState, Imports } from '../types/ReduxTypes';
/**
 * The user has just logged in, so figure out what do to next.
 */
export declare const completeLogin: (account: EdgeAccount) => (dispatch: Dispatch, getState: GetState, imports: Imports) => Promise<void>;
/**
 * Everything is done, and we can pass the account to the outside world.
 */
export declare const submitLogin: (account: EdgeAccount) => (dispatch: Dispatch, getState: GetState, imports: Imports) => Promise<void>;
