import { Action, Dispatch, GetState, Imports } from '../types/ReduxTypes';
/**
 * Fires off all the things we need to do to get the login scene up & running.
 */
export declare const initializeLogin: () => (dispatch: Dispatch, getState: GetState, imports: Imports) => Promise<void>;
export declare const maybeRouteComplete: (fallbackAction: Action) => (dispatch: Dispatch, getState: GetState, imports: Imports) => void;
