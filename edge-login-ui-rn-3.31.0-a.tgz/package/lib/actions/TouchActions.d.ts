import { TouchState } from '../reducers/TouchReducer';
import { Dispatch } from '../types/ReduxTypes';
/**
 * Figures out whether or not biometric logins are available,
 * and saves that to redux.
 */
export declare const loadTouchState: () => (dispatch: Dispatch) => Promise<TouchState>;
