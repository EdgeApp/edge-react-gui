import { Dispatch, GetState, Imports } from '../types/ReduxTypes';
/**
 * Ask the user for the username that goes with a recovery key,
 * then launches the questions scene.
 */
export declare const launchPasswordRecovery: (recoveryKey: string) => (dispatch: Dispatch, getState: GetState, imports: Imports) => Promise<void>;
