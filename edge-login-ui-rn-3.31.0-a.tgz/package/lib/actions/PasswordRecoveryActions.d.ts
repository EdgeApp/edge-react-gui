import { EdgeAccount } from 'edge-core-js';
import { Branding } from '../types/Branding';
import { Dispatch, GetState, Imports } from '../types/ReduxTypes';
/**
 * Prepares what is needed for the change recovery scene.
 */
export declare const initializeChangeRecovery: (account: EdgeAccount) => (dispatch: Dispatch, getState: GetState, imports: Imports) => Promise<void>;
export declare function sendRecoveryEmail(emailAddress: string, username: string, recoveryKey: string, branding: Branding): Promise<void>;
export declare function shareRecovery(username: string, recoveryKey: string, branding: Branding): Promise<void>;
