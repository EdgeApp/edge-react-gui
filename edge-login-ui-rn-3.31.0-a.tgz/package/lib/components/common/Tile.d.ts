import * as React from 'react';
import { ThemeProps } from '../services/ThemeContext';
interface OwnProps {
    body?: string;
    children?: React.ReactNode;
    error?: boolean;
    onPress?: () => void | Promise<void>;
    title: string;
    type: 'editable' | 'questionable' | 'loading' | 'static' | 'touchable';
    contentPadding?: boolean;
    maximumHeight?: 'small' | 'medium' | 'large';
    disabled?: boolean;
}
type Props = OwnProps & ThemeProps;
export declare class TileComponent extends React.PureComponent<Props> {
    render(): JSX.Element;
}
export declare const Tile: (props: Pick<Props, keyof OwnProps>) => JSX.Element;
export {};
