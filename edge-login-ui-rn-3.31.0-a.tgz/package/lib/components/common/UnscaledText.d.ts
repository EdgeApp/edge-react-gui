import * as React from 'react';
import { TextProps } from 'react-native';
import { AnimatedProps } from 'react-native-reanimated';
export declare const UnscaledText: React.FC<TextProps>;
export declare const AnimatedUnscaledText: React.FC<AnimatedProps<TextProps>>;
