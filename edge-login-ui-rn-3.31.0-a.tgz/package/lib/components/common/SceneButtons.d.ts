/**
 * IMPORTANT: Changes in this file MUST be synced between edge-react-gui and
 * edge-login-ui-rn!
 */
/// <reference types="react" />
import { ButtonsViewProps } from '../buttons/ButtonsView';
interface Props extends Omit<Omit<ButtonsViewProps, 'parentType'>, 'layout'> {
}
export declare const SceneButtons: (props: Props) => JSX.Element;
export {};
