/**
 * IMPORTANT: Changes in this file MUST be synced between edge-react-gui and
 * edge-login-ui-rn!
 */
import * as React from 'react';
import { ViewProps } from 'react-native';
import { LinearTransition } from 'react-native-reanimated';
export declare const DEFAULT_ANIMATION_DURATION_MS = 300;
export declare const LAYOUT_ANIMATION: LinearTransition;
export declare const MAX_LIST_ITEMS_ANIM = 10;
export declare const fadeIn: Anim;
export declare const fadeInUp: Anim;
export declare const fadeInUp20: Anim;
export declare const fadeInUp25: Anim;
export declare const fadeInUp30: Anim;
export declare const fadeInUp40: Anim;
export declare const fadeInUp50: Anim;
export declare const fadeInUp60: Anim;
export declare const fadeInUp80: Anim;
export declare const fadeInUp90: Anim;
export declare const fadeInUp110: Anim;
export declare const fadeInUp120: Anim;
export declare const fadeInUp140: Anim;
export declare const fadeInDown: Anim;
export declare const fadeInDown10: Anim;
export declare const fadeInDown20: Anim;
export declare const fadeInDown30: Anim;
export declare const fadeInDown40: Anim;
export declare const fadeInDown50: Anim;
export declare const fadeInDown60: Anim;
export declare const fadeInDown75: Anim;
export declare const fadeInDown80: Anim;
export declare const fadeInDown90: Anim;
export declare const fadeInDown110: Anim;
export declare const fadeInDown120: Anim;
export declare const fadeInDown140: Anim;
export declare const fadeInLeft: Anim;
export declare const fadeOut: Anim;
type AnimTypeFadeIns = 'fadeIn' | 'fadeInDown' | 'fadeInUp' | 'fadeInLeft' | 'fadeInRight';
type AnimTypeFadeOuts = 'fadeOut' | 'fadeOutDown' | 'fadeOutUp' | 'fadeOutLeft' | 'fadeOutRight';
type AnimTypeStretchIns = 'stretchInY';
type AnimTypeStretchOuts = 'stretchOutY';
type AnimType = AnimTypeFadeIns | AnimTypeFadeOuts | AnimTypeStretchIns | AnimTypeStretchOuts;
interface Anim {
    type: AnimType;
    delay?: number;
    duration?: number;
    distance?: number;
}
interface Props extends ViewProps {
    disableAnimation?: boolean;
    enter?: Anim;
    exit?: Anim;
    visible?: boolean;
}
export declare const EdgeAnim: React.MemoExoticComponent<({ children, disableAnimation, enter, exit, visible, ...rest }: Props) => JSX.Element | null>;
export {};
