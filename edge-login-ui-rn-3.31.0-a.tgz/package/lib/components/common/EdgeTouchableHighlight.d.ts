/// <reference types="react" />
import { TouchableHighlightProps } from 'react-native';
import { ExtendedProps } from '../hoc/withExtendedTouchable';
export declare const EdgeTouchableHighlight: React.FC<TouchableHighlightProps & {
    children?: React.ReactNode;
} & ExtendedProps>;
