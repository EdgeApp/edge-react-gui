/// <reference types="react" />
interface Props {
    data: string;
    size: number;
    padding?: number;
    backgroundColor?: string;
    foregroundColor?: string;
}
/**
 * Renders a QR code.
 */
export declare function QrCode(props: Props): JSX.Element;
export {};
