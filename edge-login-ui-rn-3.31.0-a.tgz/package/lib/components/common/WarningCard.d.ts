/// <reference types="react" />
interface Props {
    title: string;
    header?: string | null;
    points?: string[] | null;
    footer?: string | null;
    marginRem?: number[] | number;
    paddingRem?: number[] | number;
}
/**
 * A warning card that accepts a title, header, bullet points and a footer,
 * rendering the bullet points with the correct vertical alignment when
 * the messages overflow.
 *  .___________________________.
 *  | ⚠ Warning                 |
 *  |                           |
 *  | This is the header text   |
 *  |                           |
 *  | • This is an overflowing  |
 *  |   bulletpoint message     |
 *  | • This one's short        |
 *  |                           |
 *  | This is the footer text   |
 *  |___________________________|
 */
export declare function WarningCard({ title, header, points, footer, marginRem, paddingRem }: Props): JSX.Element;
export {};
