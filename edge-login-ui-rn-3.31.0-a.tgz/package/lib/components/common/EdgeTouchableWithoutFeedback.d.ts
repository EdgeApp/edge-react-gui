/// <reference types="react" />
import { TouchableWithoutFeedbackProps } from 'react-native';
import { ExtendedProps } from '../hoc/withExtendedTouchable';
export declare const EdgeTouchableWithoutFeedback: React.FC<TouchableWithoutFeedbackProps & {
    children?: React.ReactNode;
} & ExtendedProps>;
