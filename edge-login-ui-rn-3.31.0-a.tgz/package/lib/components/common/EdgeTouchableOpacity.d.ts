/// <reference types="react" />
export declare const EdgeTouchableOpacity: import("react").FC<import("react-native").TouchableOpacityProps & import("react").RefAttributes<import("react-native").View> & {
    children?: import("react").ReactNode;
} & import("../hoc/withExtendedTouchable").ExtendedProps>;
