import * as React from 'react';
import { TextInput, TextInputProps } from 'react-native';
export declare const UnscaledTextInput: React.ForwardRefExoticComponent<TextInputProps & React.RefAttributes<TextInput>>;
