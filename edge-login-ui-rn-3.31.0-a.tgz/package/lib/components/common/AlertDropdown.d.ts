/// <reference types="react" />
import { AirshipBridge } from 'react-native-airship';
import { ThemeProps } from '../services/ThemeContext';
interface Props {
    bridge: AirshipBridge<void>;
    message: string;
    warning?: boolean;
}
export declare const AlertDropdown: (props: Pick<Props & ThemeProps, keyof Props>) => JSX.Element;
export {};
