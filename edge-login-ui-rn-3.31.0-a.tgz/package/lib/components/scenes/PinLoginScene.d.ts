/// <reference types="react" />
import { Branding } from '../../types/Branding';
import { SceneProps } from '../../types/routerTypes';
export interface PinLoginParams {
    loginId: string;
}
interface Props extends SceneProps<'pinLogin'> {
    branding: Branding;
}
export declare function PinLoginScene(props: Props): JSX.Element;
export {};
