/// <reference types="react" />
import { Branding } from '../../types/Branding';
import { SceneProps } from '../../types/routerTypes';
interface Props extends SceneProps<'landing'> {
    branding: Branding;
}
export declare const LandingScene: (props: Props) => JSX.Element;
export {};
