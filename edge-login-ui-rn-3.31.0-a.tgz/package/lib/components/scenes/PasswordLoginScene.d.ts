/// <reference types="react" />
import { Branding } from '../../types/Branding';
import { SceneProps } from '../../types/routerTypes';
export interface PasswordLoginParams {
    username: string;
}
interface Props extends SceneProps<'passwordLogin'> {
    branding: Branding;
}
export declare const PasswordLoginScene: (props: Props) => JSX.Element;
export {};
