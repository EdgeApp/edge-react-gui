/// <reference types="react" />
import { EdgeAccount } from 'edge-core-js';
import { Branding } from '../../../types/Branding';
import { SceneProps } from '../../../types/routerTypes';
export interface ChangeRecoveryParams {
    questionsList: string[];
    userQuestions: string[];
    account: EdgeAccount;
}
interface Props extends SceneProps<'changeRecovery'> {
    branding: Branding;
}
export declare const ChangeRecoveryScene: (props: Props) => JSX.Element;
export {};
