/// <reference types="react" />
import { EdgeAccount, OtpError } from 'edge-core-js';
import { Branding } from '../../../types/Branding';
import { SceneProps } from '../../../types/routerTypes';
export interface OtpRepairParams {
    account: EdgeAccount;
    otpError: OtpError;
}
interface Props extends SceneProps<'otpRepair'> {
    branding: Branding;
}
export declare function OtpRepairScene(props: Props): JSX.Element;
export {};
