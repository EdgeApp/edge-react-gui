/// <reference types="react" />
import { EdgeAccount } from 'edge-core-js';
import { Branding } from '../../../types/Branding';
import { SceneProps } from '../../../types/routerTypes';
export interface ChangeUsernameParams {
    account: EdgeAccount;
    password: string;
}
interface ChangeUsernameProps extends SceneProps<'changeUsername'> {
    branding: Branding;
}
/**
 * The standalone username change scene that completes immediately.
 */
export declare const ChangeUsernameScene: (props: ChangeUsernameProps) => JSX.Element;
export {};
