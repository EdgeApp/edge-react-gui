import { EdgeAccount, EdgePendingVoucher } from 'edge-core-js';
import * as React from 'react';
import { SceneProps } from '../../../types/routerTypes';
import { ThemeProps } from '../../services/ThemeContext';
export interface SecurityAlertParams {
    account: EdgeAccount;
}
interface OwnProps extends SceneProps<'securityAlert'> {
}
interface StateProps {
    account: EdgeAccount;
}
interface DispatchProps {
    startResecure: (account: EdgeAccount) => void;
    onDone: () => void;
}
type Props = OwnProps & StateProps & DispatchProps & ThemeProps;
interface State {
    needsResecure: boolean;
    otpResetDate: Date | undefined;
    pendingVouchers: EdgePendingVoucher[];
    spinReset: boolean;
    spinVoucher: {
        [voucherId: string]: boolean;
    };
}
export declare class SecurityAlertsSceneComponent extends React.Component<Props, State> {
    cleanups: Array<() => unknown> | undefined;
    constructor(props: Props);
    componentDidMount(): void;
    componentWillUnmount(): void;
    render(): JSX.Element;
    renderReset(): React.ReactNode;
    renderVouchers(): React.ReactNode;
    handleApproveReset: () => void;
    handleDeny: (pendingVoucher: EdgePendingVoucher) => () => Promise<void>;
    handleApproveVoucher: (pendingVoucher: EdgePendingVoucher) => () => Promise<void>;
    handleDenyAll: () => Promise<void>;
    handleSkip: () => void;
    checkEmpty: () => void;
}
export declare function SecurityAlertsScene(props: OwnProps): JSX.Element;
export {};
