/// <reference types="react" />
import { SceneProps } from '../../types/routerTypes';
export interface RecoveryLoginParams {
    username: string;
    recoveryKey: string;
    userQuestions: string[];
}
export declare const RecoveryLoginScene: (props: SceneProps<'recoveryLogin'>) => JSX.Element;
