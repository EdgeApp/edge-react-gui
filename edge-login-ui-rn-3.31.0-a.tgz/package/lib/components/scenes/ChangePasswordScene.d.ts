/// <reference types="react" />
import { EdgeAccount } from 'edge-core-js';
import { SceneProps } from '../../types/routerTypes';
export interface ChangePasswordParams {
    account: EdgeAccount;
}
export interface NewAccountPasswordParams {
    password?: string;
    pin?: string;
    username?: string;
}
export interface ResecurePasswordParams {
    account: EdgeAccount;
}
export interface UpgradePasswordParams {
    account: EdgeAccount;
    password?: string;
    username: string;
}
export declare const ChangePasswordScene: (props: SceneProps<'changePassword'>) => JSX.Element;
export declare const ResecurePasswordScene: (props: SceneProps<'resecurePassword'>) => JSX.Element;
export declare const NewAccountPasswordScene: (props: SceneProps<'newAccountPassword'>) => JSX.Element;
export declare const UpgradePasswordScene: (props: SceneProps<'upgradePassword'>) => JSX.Element;
