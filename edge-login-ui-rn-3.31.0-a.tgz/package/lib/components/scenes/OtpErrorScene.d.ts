/// <reference types="react" />
import { OtpError } from 'edge-core-js';
import { SceneProps } from '../../types/routerTypes';
import { LoginAttempt } from '../../util/loginAttempt';
export interface OtpErrorParams {
    otpAttempt: LoginAttempt;
    otpError: OtpError;
}
interface Props extends SceneProps<'otpError'> {
}
export declare function OtpErrorScene(props: Props): JSX.Element;
export {};
