/// <reference types="react" />
import { Branding } from '../../../types/Branding';
import { SceneProps } from '../../../types/routerTypes';
interface Props extends SceneProps<'newAccountWelcome'> {
    branding: Branding;
}
export declare const NewAccountWelcomeScene: (props: Props) => JSX.Element;
export {};
