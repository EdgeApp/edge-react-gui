/// <reference types="react" />
import { EdgeAccount } from 'edge-core-js';
import { SceneProps } from '../../../types/routerTypes';
export interface NewAccountReviewParams {
    account: EdgeAccount;
    password?: string;
    pin: string;
    username?: string;
}
export interface UpgradeAccountReviewParams {
    password: string;
    pin?: string;
    username: string;
}
/**
 * The review scene for new accounts.
 */
export declare const NewAccountReviewScene: (props: SceneProps<'newAccountReview'>) => JSX.Element;
/**
 * The review scene for upgrading (light) accounts.
 */
export declare const UpgradeReviewScene: (props: SceneProps<'upgradeAccountReview'>) => JSX.Element;
