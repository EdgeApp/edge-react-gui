/// <reference types="react" />
import { SceneProps } from '../../../types/routerTypes';
export interface NewAccountWaitParams {
    title: string;
    message: string;
}
export declare const NewAccountWaitScene: (props: SceneProps<'newAccountWait'>) => JSX.Element;
