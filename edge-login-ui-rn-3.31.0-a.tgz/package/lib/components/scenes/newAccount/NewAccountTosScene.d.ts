/// <reference types="react" />
import { EdgeAccount } from 'edge-core-js';
import { Branding } from '../../../types/Branding';
import { SceneProps } from '../../../types/routerTypes';
export interface UpgradeTosParams {
    account: EdgeAccount;
    password: string;
    username: string;
}
export interface NewAccountTosParams {
    password?: string;
    pin: string;
    username?: string;
}
/**
 * Terms of Service scene for new full accounts
 */
interface NewAccountTosProps extends SceneProps<'newAccountTos'> {
    branding: Branding;
}
export declare const NewAccountTosScene: (props: NewAccountTosProps) => JSX.Element;
/**
 * Terms of Service scene for upgrading existing (light) accounts
 */
interface UpgradeTosProps extends SceneProps<'upgradeTos'> {
    branding: Branding;
}
export declare const UpgradeTosScene: (props: UpgradeTosProps) => JSX.Element;
export {};
