/// <reference types="react" />
import { EdgeAccount } from 'edge-core-js';
import { SceneProps } from '../../types/routerTypes';
export interface ChangePinParams {
    account: EdgeAccount;
}
export interface NewAccountPinParams {
    password?: string;
    pin?: string;
    username?: string;
}
export interface ResecurePinParams {
    account: EdgeAccount;
}
export declare const ChangePinScene: (props: SceneProps<'changePin'>) => JSX.Element;
export declare const ResecurePinScene: (props: SceneProps<'resecurePin'>) => JSX.Element;
export declare const NewAccountPinScene: (props: SceneProps<'newAccountPin'>) => JSX.Element;
