/// <reference types="react" />
import { SceneProps } from '../../types/routerTypes';
export declare function LoadingScene(props: SceneProps<'loading'>): JSX.Element;
