/// <reference types="react" />
type Key = '0' | '1' | '2' | '3' | '4' | '5' | '6' | '7' | '8' | '9' | 'back';
interface Props {
    disabled?: boolean;
    onPress: (key: Key) => void;
}
export declare function PinKeypad(props: Props): JSX.Element;
export {};
