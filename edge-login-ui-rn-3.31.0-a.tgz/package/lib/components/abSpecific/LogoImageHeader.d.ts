/// <reference types="react" />
import { Branding } from '../../types/Branding';
interface Props {
    branding: Branding;
}
export declare function LogoImageHeader(props: Props): JSX.Element;
export {};
