/// <reference types="react" />
import { LayoutChangeEvent } from 'react-native';
import { LoginUserInfo } from '../../hooks/useLocalUsers';
interface Props {
    userInfo: LoginUserInfo;
    onClick: (userInfo: LoginUserInfo) => void;
    onDelete: (userInfo: LoginUserInfo) => void;
    onLayout: (event: LayoutChangeEvent) => void;
}
export declare function UserListItem(props: Props): JSX.Element;
export {};
