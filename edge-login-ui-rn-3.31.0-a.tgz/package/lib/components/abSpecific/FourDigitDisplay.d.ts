/// <reference types="react" />
interface Props {
    error: string | null;
    pin: string;
    spinner: boolean;
}
export declare function FourDigitDisplay(props: Props): JSX.Element;
export {};
