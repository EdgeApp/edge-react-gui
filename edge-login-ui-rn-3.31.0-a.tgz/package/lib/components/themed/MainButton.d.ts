import * as React from 'react';
export type MainButtonType = 'primary' | 'secondary' | 'escape';
interface Props {
    children?: React.ReactNode;
    onPress?: () => void | Promise<void>;
    disabled?: boolean;
    label?: string;
    marginRem?: number[] | number;
    spinner?: boolean;
    type?: MainButtonType;
    layout?: 'row' | 'column' | 'solo';
}
/**
 * @deprecated
 * Use EdgeButton instead, and consider whether there is a genuine need for
 * special margins in MainButton use cases from a UI4 design perspective.
 */
export declare function MainButton(props: Props): JSX.Element;
export {};
