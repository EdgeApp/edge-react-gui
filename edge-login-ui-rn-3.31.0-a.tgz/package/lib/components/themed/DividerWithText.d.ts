/// <reference types="react" />
import { ThemeProps } from '../services/ThemeContext';
interface Props {
    label?: string;
}
export declare const DividerWithText: (props: Pick<Props & ThemeProps, "label">) => JSX.Element;
export {};
