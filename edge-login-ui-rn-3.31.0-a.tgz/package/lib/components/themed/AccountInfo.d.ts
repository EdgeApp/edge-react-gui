/// <reference types="react" />
interface Props {
    username?: string;
    password?: string;
    pin?: string;
    marginRem?: number[] | number;
    onOpen?: () => void;
}
export declare const AccountInfo: (props: Props) => JSX.Element;
export {};
