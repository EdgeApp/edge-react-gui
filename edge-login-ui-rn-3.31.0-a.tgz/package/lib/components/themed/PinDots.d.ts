/// <reference types="react" />
interface Props {
    pinLength: number;
    maxLength: number;
}
export declare function PinDots({ maxLength, pinLength }: Props): JSX.Element;
export {};
