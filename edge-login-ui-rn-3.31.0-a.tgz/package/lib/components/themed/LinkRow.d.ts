import * as React from 'react';
import { Theme } from '../services/ThemeContext';
interface Props {
    onPress?: () => void | Promise<void>;
    label?: string;
    marginRem?: number[] | number;
    renderIcon?: (theme: Theme) => React.ReactNode;
}
export declare function LinkRow(props: Props): JSX.Element;
export {};
