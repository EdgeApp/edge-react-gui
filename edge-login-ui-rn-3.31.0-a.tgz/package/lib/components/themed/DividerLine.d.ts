/// <reference types="react" />
interface Props {
    marginRem?: number | number[];
}
/**
 * A horizontal line for dividing sections of the app.
 *
 * This is designed to "stick out" to the right of the content area,
 * touching the edge of the screen. Just add the same horizontal
 * margin to this component as you would to its siblings,
 * such as buttons or text fields, and everything will line up.
 */
export declare const DividerLine: (props: Props) => JSX.Element;
export {};
