import * as React from 'react';
interface Props {
    children: React.ReactNode;
    visible: boolean;
    duration?: number;
    hidden?: boolean;
}
export declare const Fade: (props: Props) => JSX.Element;
export {};
