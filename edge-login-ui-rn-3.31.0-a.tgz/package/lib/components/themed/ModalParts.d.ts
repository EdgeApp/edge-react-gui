/**
 * IMPORTANT: Changes in this file MUST be synced with edge-react-gui!
 */
import * as React from 'react';
interface ModalTitleProps {
    children: React.ReactNode;
    center?: boolean;
    paddingRem?: number[] | number;
    icon?: React.ReactNode;
}
interface ModalFooterProps {
    onPress: () => void;
}
export declare function ModalTitle(props: ModalTitleProps): JSX.Element;
export declare function ModalMessage(props: {
    children: React.ReactNode;
    paddingRem?: number[] | number;
    isWarning?: boolean;
}): JSX.Element;
/**
 * Renders a close button
 */
export declare function ModalFooter(props: ModalFooterProps): JSX.Element;
export declare namespace ModalFooter {
    var bottomRem: number;
}
/**
 * A consistently styled scroll area for use in modals. Should only be used
 * within ThemedModal.
 */
export declare function ModalScrollArea(props: {
    children: React.ReactNode;
}): JSX.Element;
/**
 * For fading the bottom of the modal if the modal caller has its own special
 * scroll implementation and does not use the ThemedModal's built-in 'scroll'
 * prop
 */
export declare const ModalFooterFade: () => JSX.Element;
export {};
