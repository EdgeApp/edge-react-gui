/**
 * IMPORTANT: Changes in this file MUST be synced between edge-react-gui and
 * edge-login-ui-rn!
 */
import * as React from 'react';
import { SharedValue } from 'react-native-reanimated';
import { SpaceProps } from '../../hooks/useSpaceStyle';
import { AnimatedIconComponent } from '../icons/ThemedIcons';
export type FilledTextInputReturnKeyType = 'done' | 'go' | 'next' | 'search' | 'send';
export interface FilledTextInputProps extends SpaceProps {
    value: string;
    error?: string;
    valid?: string;
    placeholder?: string;
    numeric?: boolean;
    minDecimals?: number;
    maxDecimals?: number;
    clearIcon?: boolean;
    iconComponent?: AnimatedIconComponent | null;
    multiline?: boolean;
    scale?: SharedValue<number>;
    showSpinner?: boolean;
    prefix?: string;
    suffix?: string;
    textsizeRem?: number;
    onBlur?: () => void;
    onChangeText?: (text: string) => void;
    onClear?: () => void;
    onFocus?: () => void;
    autoCapitalize?: 'none' | 'sentences' | 'words' | 'characters';
    autoCorrect?: boolean;
    blurOnSubmit?: boolean;
    inputAccessoryViewID?: string;
    keyboardType?: 'default' | 'number-pad' | 'decimal-pad' | 'numeric' | 'email-address' | 'phone-pad' | 'visible-password';
    maxLength?: number;
    onSubmitEditing?: () => void;
    returnKeyType?: FilledTextInputReturnKeyType;
    secureTextEntry?: boolean;
    testID?: string;
    autoFocus?: boolean;
    blurOnClear?: boolean;
    disabled?: boolean;
}
/**
 * Type definitions for our static methods.
 * Create a ref object using `useRef<FilledTextInputRef>(null)` or
 * `const ref = createRef<FilledTextInputRef>()`
 */
export interface FilledTextInputRef {
    focus: () => void;
    blur: () => void;
    isFocused: () => boolean;
    clear: () => void;
    setNativeProps: (nativeProps: Object) => void;
}
export declare const FilledTextInput: React.ForwardRefExoticComponent<FilledTextInputProps & React.RefAttributes<FilledTextInputRef>>;
