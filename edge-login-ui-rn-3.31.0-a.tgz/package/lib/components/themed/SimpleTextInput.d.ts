import * as React from 'react';
import { SharedValue } from 'react-native-reanimated';
import { SpaceProps } from '../../hooks/useSpaceStyle';
import { AnimatedIconComponent } from '../icons/ThemedIcons';
export type SimpleTextInputReturnKeyType = 'done' | 'go' | 'next' | 'search' | 'send';
export interface SimpleTextInputProps extends SpaceProps {
    value: string;
    placeholder?: string;
    iconComponent?: AnimatedIconComponent | null;
    scale?: SharedValue<number>;
    onBlur?: () => void;
    onChangeText?: (text: string) => void;
    onClear?: () => void;
    onFocus?: () => void;
    autoCapitalize?: 'none' | 'sentences' | 'words' | 'characters';
    autoCorrect?: boolean;
    blurOnSubmit?: boolean;
    inputAccessoryViewID?: string;
    keyboardType?: 'default' | 'number-pad' | 'decimal-pad' | 'numeric' | 'email-address' | 'phone-pad';
    maxLength?: number;
    onSubmitEditing?: () => void;
    returnKeyType?: SimpleTextInputReturnKeyType;
    secureTextEntry?: boolean;
    testID?: string;
    autoFocus?: boolean;
    blurOnClear?: boolean;
    disabled?: boolean;
}
/**
 * Type definitions for our static methods.
 * Create a ref object using `useRef<SimpleTextInputRef>(null)` or
 * `const ref = createRef<SimpleTextInputRef>()`
 */
export interface SimpleTextInputRef {
    focus: () => void;
    blur: () => void;
    isFocused: () => boolean;
    clear: () => void;
    setNativeProps: (nativeProps: Object) => void;
}
export declare const SimpleTextInput: React.ForwardRefExoticComponent<SimpleTextInputProps & React.RefAttributes<SimpleTextInputRef>>;
