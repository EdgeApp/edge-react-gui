import React from 'react';
import { TextInput, TextInputProps } from 'react-native';
export declare const NumericInput: React.ForwardRefExoticComponent<{
    minDecimals?: number | undefined;
    maxDecimals?: number | undefined;
    animated?: boolean | undefined;
} & TextInputProps & React.RefAttributes<TextInput>>;
