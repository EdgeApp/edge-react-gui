/**
 * IMPORTANT: Changes in this file MUST be synced with edge-react-gui!
 */
import * as React from 'react';
import { StyleProp, TextProps, TextStyle } from 'react-native';
import { Theme } from '../services/ThemeContext';
export declare const androidAdjustTextStyle: (theme: Theme) => {
    top: number;
} | null;
/** A properly spaced block of text with default font color and size. Children
 * that are wrapped in other `___Text` component types will override those defaults.
 *
 * A `Paragraph` *can* have `marginRem`, but *only* to avoid an extra `View` for
 * spacing out `Paragraph(s)` in relation to their parent, *NOT* to give special
 * spacing *between* `Paragraphs` */
export declare const Paragraph: (props: {
    children: React.ReactNode;
    center?: boolean;
    /** @deprecated A `Paragraph` *can* have `marginRem`, but *only* to avoid an extra `View` for spacing out `Paragraph(s)` in relation to their parent, *NOT* to give special spacing *between* `Paragraphs`. It's still preferable to have the parents deal with spacing outside of `Paragraphs`. */
    marginRem?: number[] | number;
}) => JSX.Element;
interface LabelProps extends TextProps {
    children: React.ReactNode;
    ellipsizeMode?: 'head' | 'middle' | 'tail' | 'clip';
    numberOfLines?: number;
    disableFontScaling?: boolean;
    minimumFontScale?: number;
    /** @deprecated Use or create an appropriate `___Text` component instead */
    style?: StyleProp<TextStyle>;
}
export declare const EdgeText: (props: LabelProps) => JSX.Element;
/** Makes the contents of an `EdgeText` or `Paragraph` smaller (0.75rem).
 * Unless used within a `Paragraph` block, provides no outer spacing. */
export declare const SmallText: (props: {
    children: React.ReactNode;
}) => JSX.Element;
/** Makes the contents of an `EdgeText` or `Paragraph` orange, for warnings.
 * Unless used within a `Paragraph` block, provides no outer spacing. */
export declare const WarningText: (props: {
    children: React.ReactNode;
}) => JSX.Element;
/** Makes the contents of an `EdgeText` or `Paragraph` large (1.5rem).
 * Unless used within a `Paragraph` block, provides no outer spacing. */
export declare const HeaderText: (props: {
    children: React.ReactNode;
}) => JSX.Element;
export {};
