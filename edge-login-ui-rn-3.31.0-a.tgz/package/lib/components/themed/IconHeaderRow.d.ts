import * as React from 'react';
import { Theme, ThemeProps } from '../services/ThemeContext';
interface Props {
    children?: React.ReactNode;
    renderIcon: (theme: Theme) => React.ReactNode;
}
export declare const IconHeaderRow: (props: Pick<Props & ThemeProps, keyof Props>) => JSX.Element;
export {};
