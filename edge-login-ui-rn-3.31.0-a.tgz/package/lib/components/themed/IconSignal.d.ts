import * as React from 'react';
import { ThemeProps } from '../services/ThemeContext';
interface IconProps {
    size?: number;
    color?: string;
}
interface Props {
    enabledIcon: React.ComponentType<IconProps>;
    disabledIcon: React.ComponentType<IconProps>;
    enabled: boolean;
}
export declare const IconSignal: (props: Pick<Props & ThemeProps, keyof Props>) => JSX.Element;
export {};
