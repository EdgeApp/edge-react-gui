import * as React from 'react';
import { Branding } from '../../types/Branding';
interface Props {
    children?: React.ReactNode;
    backButtonText?: string;
    branding?: Branding;
    noUnderline?: boolean;
    onBack?: () => void;
    onSkip?: () => void;
    title?: string;
    paddingRem?: number | number[];
}
export declare function ThemedScene(props: Props): JSX.Element;
export {};
