import * as React from 'react';
import { ThemeProps } from '../services/ThemeContext';
interface OwnProps {
    children: React.ReactNode;
    title?: string;
    isWarning?: Boolean;
    marginRem?: number[] | number;
    numberOfLines?: number;
    titleNumberOfLines?: number;
    invisible?: boolean;
}
export declare const FormError: (props: Pick<OwnProps & ThemeProps, keyof OwnProps>) => JSX.Element;
export {};
