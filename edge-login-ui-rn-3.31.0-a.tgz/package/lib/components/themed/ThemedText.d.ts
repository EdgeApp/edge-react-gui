import * as React from 'react';
interface NativeProps {
    ellipsizeMode?: 'head' | 'middle' | 'tail' | 'clip';
    lineBreakMode?: 'head' | 'middle' | 'tail' | 'clip';
    numberOfLines?: number;
    onLayout?: (event: any) => void;
    onTextLayout?: (event: any) => void;
    onPress?: (event: any) => void;
    onLongPress?: (event: any) => void;
    style?: any;
    testID?: string;
    nativeID?: string;
    maxFontSizeMultiplier?: number | null;
}
/**
 * A lightweight wrapper around the React Native Text component,
 * which simply sets up some default styles.
 */
export declare function ThemedText(props: NativeProps): JSX.Element;
/**
 * A scene or modal title.
 */
export declare function TitleText(props: {
    children: React.ReactNode;
}): JSX.Element;
/**
 * A paragraph of body text within a modal or scene.
 */
export declare function MessageText(props: {
    children: React.ReactNode;
}): JSX.Element;
/**
 * Use this component just like its HTML equivalent,
 * to wrap text that is of greater importance (bolder).
 */
export declare function Strong(props: {
    children: React.ReactNode;
}): JSX.Element;
/**
 * Wraps text that communicates danger, like unusually high fees.
 */
export declare function Warning(props: {
    children: React.ReactNode;
}): JSX.Element;
/**
 * Wraps text that communicates a problem, like insufficent funds.
 */
export declare function Error(props: {
    children: React.ReactNode;
}): JSX.Element;
export {};
