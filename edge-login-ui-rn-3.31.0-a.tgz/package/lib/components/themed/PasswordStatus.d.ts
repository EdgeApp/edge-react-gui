/// <reference types="react" />
/**
 * 'met' or 'unmet' while user is editing the password fields, 'error' if any
 * requirements are still unmet upon submission.
 *
 * 'met': green, 'unmet': white, 'error': red
 * */
export type PasswordRequirementStatus = 'met' | 'unmet' | 'error';
/** Conditions that must be met in order for the password to be accepted. */
export interface PasswordRequirements {
    minLengthMet: PasswordRequirementStatus;
    hasNumber: PasswordRequirementStatus;
    hasLowercase: PasswordRequirementStatus;
    hasUppercase: PasswordRequirementStatus;
    confirmationMatches: PasswordRequirementStatus;
}
interface Props {
    passwordReqs: PasswordRequirements;
}
export declare const PasswordStatus: (props: Props) => JSX.Element;
export {};
