import * as React from 'react';
interface Props {
    children?: React.ReactNode;
    onPress?: () => void | Promise<void>;
    label?: string;
    testID?: string;
}
/**
 * A stand-alone button to perform the primary action in a modal or scene.
 */
export declare function PinButton(props: Props): JSX.Element;
export {};
