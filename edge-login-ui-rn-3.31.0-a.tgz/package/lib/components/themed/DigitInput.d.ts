/// <reference types="react" />
export declare const MAX_PIN_LENGTH = 4;
interface Props {
    testID?: string;
    pin: string;
    maxPinLength?: number;
    marginRem?: number[] | number;
    onChangePin: (newPin: string) => void;
}
export declare const DigitInput: (props: Props) => JSX.Element;
export {};
