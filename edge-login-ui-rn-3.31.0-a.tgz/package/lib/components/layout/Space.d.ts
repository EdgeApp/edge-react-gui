/**
 * IMPORTANT: Changes in this file MUST be synced between edge-react-gui and
 * edge-login-ui-rn!
 */
import * as React from 'react';
import { MarginRemProps } from '../../hooks/useMarginRemStyle';
export interface SpaceProps extends MarginRemProps {
    /** Align children to the top */
    alignBottom?: boolean;
    /** Align children to the top */
    alignLeft?: boolean;
    /** Align children to the right */
    alignRight?: boolean;
    /** Align children to the top */
    alignTop?: boolean;
    /** Aligns children to the center */
    alignCenter?: boolean;
    /** Aligns children to the center horizontally */
    alignHorizontal?: boolean;
    /** Aligns children to the center vertically */
    alignVertical?: boolean;
    children?: React.ReactNode;
    /**
     * The `expand` space prop tells a component to expand its size within its
     * parent component.
     *
     * This is particularly useful when you want to use the space props to
     * align the component.
     */
    expand?: boolean;
    /**
     * Changes the orientation of child component layout from column
     * (top-to-bottom) to row (left-to-right).
     *
     * The `row` prop is an additional, non-space props useful managing the
     * stacking direction of child components. By default, child components stack
     * vertically (column-based), from top to bottom. If `row={true}`, then
     * child components stack horizontally (row-based).
     *
     * The `row` prop does not affect the alignment or rem props (i.e. vertical
     * is always vertical regardless of the value set for the `row` prop).
     */
    row?: boolean;
}
export declare const Space: React.MemoExoticComponent<(props: SpaceProps) => JSX.Element>;
