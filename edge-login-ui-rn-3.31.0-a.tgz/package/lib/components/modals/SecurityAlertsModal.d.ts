/// <reference types="react" />
import { EdgeLoginMessage } from 'edge-core-js';
import { AirshipBridge } from 'react-native-airship';
interface Props {
    bridge: AirshipBridge<string | undefined>;
    messages: EdgeLoginMessage[];
}
export declare const SecurityAlertsModal: (props: Props) => JSX.Element;
export {};
