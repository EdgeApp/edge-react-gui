/// <reference types="react" />
import { EdgeAccount, EdgeAccountOptions, EdgeContext } from 'edge-core-js';
import { AirshipBridge } from 'react-native-airship';
interface Props {
    bridge: AirshipBridge<EdgeAccount | undefined>;
    accountOptions: EdgeAccountOptions;
    context: EdgeContext;
}
export declare function QrCodeModal(props: Props): JSX.Element;
export {};
