/// <reference types="react" />
export declare const GradientFadeOut: () => JSX.Element;
