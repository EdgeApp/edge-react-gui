import * as React from 'react';
import { ViewToken } from 'react-native';
import { AirshipBridge } from 'react-native-airship';
interface Props<T> {
    bridge: AirshipBridge<any>;
    title?: string;
    message?: string;
    textInput?: boolean;
    initialValue?: string;
    searchIcon?: boolean;
    label?: string;
    autoCorrect?: boolean;
    autoCapitalize?: 'none' | 'sentences' | 'words' | 'characters';
    returnKeyType?: 'done' | 'go' | 'next' | 'search' | 'send';
    keyboardType?: 'default' | 'number-pad' | 'decimal-pad' | 'numeric' | 'email-address' | 'phone-pad';
    blurOnSubmit?: boolean;
    inputAccessoryViewID?: string;
    maxLength?: number;
    onSubmitEditing?: (text: string) => void;
    secureTextEntry?: boolean;
    autoFocus?: boolean;
    rowsData?: T[];
    fullScreen?: boolean;
    rowComponent?: (props: T) => React.ReactElement;
    rowDataFilter?: (filterText: string, data: T, index: number) => boolean;
    onViewableItemsChanged?: (info: {
        viewableItems: ViewToken[];
        changed: ViewToken[];
    }) => void;
}
export declare function ListModal<T>({ bridge, title, message, textInput, initialValue, rowsData, fullScreen, rowComponent, rowDataFilter, onSubmitEditing, onViewableItemsChanged, label: placeholder, ...textProps }: Props<T>): JSX.Element;
export {};
