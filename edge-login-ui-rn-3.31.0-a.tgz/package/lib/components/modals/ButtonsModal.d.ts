/**
 * IMPORTANT: Changes in this file MUST be synced between edge-react-gui and
 * edge-login-ui-rn!
 */
import * as React from 'react';
import { AirshipBridge } from 'react-native-airship';
export interface ButtonInfo {
    label: string;
    onPress?: () => Promise<boolean>;
}
export interface ButtonModalProps<Buttons> {
    bridge: AirshipBridge<keyof Buttons | undefined>;
    buttons: Buttons;
    /** Used to pass non-text children, to be rendered after the title and message
     * but before the buttons themselves. */
    children?: React.ReactNode;
    /** No corner close button */
    disableCancel?: boolean;
    /** Full height (flex: 1) */
    fullScreen?: boolean;
    /** Main body message */
    message?: string;
    /** Modal title */
    title?: string;
    /** Adds a border around the modal */
    warning?: boolean;
}
/**
 * A modal with a title, message, and buttons.
 * This is an alternative to the native `Alert` component.
 *
 * Child components appear between the message and the buttons,
 * but this feature is only meant for inserting extra message elements,
 * like images or custom text formatting.
 *
 * Build a custom modal component if you need form fields, check boxes,
 * or other interactive elements.
 */
export declare function ButtonsModal<Buttons extends {
    [key: string]: ButtonInfo;
}>(props: ButtonModalProps<Buttons>): JSX.Element;
