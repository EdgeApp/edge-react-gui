/**
 * IMPORTANT: Changes in this file MUST be synced between edge-react-gui and
 * edge-login-ui-rn!
 */
import * as React from 'react';
import { AirshipBridge } from 'react-native-airship';
import { ThemeProps } from '../services/ThemeContext';
export interface Props {
    bridge: AirshipBridge<Date>;
    initialValue: Date;
}
interface State {
    darkMode: boolean;
    date: Date;
}
/**
 * Shows the native iOS date picker inside a modal.
 */
export declare class DateModalIos extends React.Component<Props & ThemeProps, State> {
    subscription: {
        remove: () => void;
    } | undefined;
    constructor(props: Props & ThemeProps);
    componentDidMount(): void;
    componentWillUnmount(): void;
    /**
     * Wrap the data picker component in an Airship modal.
     * This modal doesn't use the normal theme colors,
     * since the native component inside uses its own phone-based colors.
     */
    render(): JSX.Element;
    handleChange: (_event: unknown, date?: Date) => void;
    handleDone: () => void;
}
/**
 * Displays the native Android date picker modal,
 * using the Airship system to manage its lifetime.
 */
export declare function DateModalAndroid(props: Props): JSX.Element;
export declare const DateModal: typeof DateModalAndroid;
/**
 * Returns the date portion of a date object, formatted YYYY-MM-DD.
 * It makes sure to return the date local to the current timezone.
 *
 * It's only use-case is to convert a date object from the date picker modal
 * to a formatted string.
 *
 * @param date A JS Date Object
 * @returns the formatted date string (YYYY-MM-DD).
 */
export declare function toRecoveryDateString(date: Date): string;
export {};
