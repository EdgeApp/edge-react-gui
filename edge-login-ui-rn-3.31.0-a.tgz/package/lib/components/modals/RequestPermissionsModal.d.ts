/// <reference types="react" />
import { AirshipBridge } from 'react-native-airship';
interface Props {
    bridge: AirshipBridge<Required<PermissionsModalChoices> | undefined>;
    choices: PermissionsModalChoices;
    message: string;
}
export interface PermissionsModalChoices {
    enable?: boolean;
    optInPriceChanges: boolean;
    optInMarketing: boolean;
}
export declare function RequestPermissionsModal(props: Props): JSX.Element;
export {};
