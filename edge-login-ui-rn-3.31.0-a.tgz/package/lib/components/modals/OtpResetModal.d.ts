export declare function showResetModal(requestOtpReset: () => Promise<void>): Promise<void>;
