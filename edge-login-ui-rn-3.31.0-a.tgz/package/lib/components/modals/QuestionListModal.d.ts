/// <reference types="react" />
import { AirshipBridge } from 'react-native-airship';
interface Props {
    bridge: AirshipBridge<string | undefined>;
    title: string;
    items: string[];
    selected?: string;
}
export declare function QuestionListModal(props: Props): JSX.Element;
export {};
