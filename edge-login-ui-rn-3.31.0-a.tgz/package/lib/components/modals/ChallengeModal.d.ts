/// <reference types="react" />
import { AirshipBridge } from 'react-native-airship';
interface Props {
    bridge: AirshipBridge<boolean | undefined>;
    challengeUri: string;
}
/**
 * Retries a task if the first attempt throws a challenge error,
 * and the user successfully solves the challenge.
 */
export declare function retryOnChallenge<T, C>(opts: {
    cancelValue: C;
    saveChallenge?: (challengeId: string) => void;
    task: (challengeId: string | undefined) => Promise<T>;
}): Promise<T | C>;
export declare const ChallengeModal: (props: Props) => JSX.Element;
export {};
