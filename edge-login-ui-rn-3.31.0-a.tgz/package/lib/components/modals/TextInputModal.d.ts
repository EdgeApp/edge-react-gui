/**
 * IMPORTANT: Changes in this file MUST be duplicated in edge-react-gui!
 */
import * as React from 'react';
import { AirshipBridge } from 'react-native-airship';
interface Props {
    bridge: AirshipBridge<string | undefined>;
    onSubmit?: (text: string) => Promise<boolean | string>;
    title?: string;
    message?: string | React.ReactNode;
    initialValue?: string;
    inputLabel?: string;
    submitLabel?: string;
    warningMessage?: string;
    warning?: boolean;
    autoCapitalize?: 'none' | 'sentences' | 'words' | 'characters';
    autoFocus?: boolean;
    autoCorrect?: boolean;
    keyboardType?: 'default' | 'number-pad' | 'decimal-pad' | 'numeric' | 'email-address' | 'phone-pad';
    multiline?: boolean;
    maxLength?: number;
    returnKeyType?: 'done' | 'go' | 'next' | 'search' | 'send';
    secureTextEntry?: boolean;
}
export declare function TextInputModal(props: Props): JSX.Element;
export {};
