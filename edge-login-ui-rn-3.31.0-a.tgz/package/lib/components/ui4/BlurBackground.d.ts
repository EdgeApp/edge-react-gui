/**
 * IMPORTANT: Changes in this file MUST be synced with edge-react-gui!
 */
/// <reference types="react" />
export declare const BlurBackground: () => JSX.Element;
