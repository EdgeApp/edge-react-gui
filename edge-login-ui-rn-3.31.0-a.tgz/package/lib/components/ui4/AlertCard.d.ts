/**
 * IMPORTANT: Changes in this file MUST be synced with edge-react-gui!
 */
/// <reference types="react" />
interface Props {
    body?: string[] | string;
    title?: string;
    type: 'error' | 'warning';
    footer?: string;
    header?: string;
    marginRem?: number[] | number;
    onPress?: () => void;
}
/**
 * A warning or error card that accepts a title, header, bullet points OR normal
 * message, and a footer. The body is considered bullet pointed if an array of
 * strings is given.
 * Bullet points, if provided, are rendered with the correct vertical alignment when
 * the messages overflow.
 *  .___________________________.
 *  | ⚠ Title Text              |
 *  |                           |
 *  | This is the header text   |
 *  |                           |
 *  | • This is an overflowing  |
 *  |   bulletpoint message     |
 *  | • This one's short        |
 *  |                           |
 *  | This is the footer text   |
 *  |___________________________|
 */
export declare function AlertCard(props: Props): JSX.Element;
export {};
