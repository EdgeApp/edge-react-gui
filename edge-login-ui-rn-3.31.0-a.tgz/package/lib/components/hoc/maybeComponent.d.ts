/**
 * IMPORTANT: Changes in this file MUST be synced between edge-react-gui and
 * edge-login-ui-rn!
 */
import React from 'react';
/**
 * Either render the given component or a React.Fragment component depending on
 * a `when` prop.
 *
 * @param Component the component to render if `when={true}`
 * @returns
 */
export declare function maybeComponent<Props>(Component: React.ComponentType<Props>): React.ComponentType<Props & {
    children?: React.ReactNode;
    when: boolean;
}>;
