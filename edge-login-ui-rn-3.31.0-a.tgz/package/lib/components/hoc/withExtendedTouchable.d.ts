import React, { ComponentType, ReactNode } from 'react';
import { GestureResponderEvent, TouchableHighlightProps, TouchableOpacityProps, TouchableWithoutFeedbackProps } from 'react-native';
type PressFn = (event: GestureResponderEvent) => void | Promise<void>;
export interface ExtendedProps {
    onPress?: PressFn;
    onLongPress?: PressFn;
    awaitChild?: ReactNode;
    debounce?: boolean;
}
type PropsWithOptionalChildren<P = unknown> = P & {
    children?: ReactNode;
};
export declare function withExtendedTouchable<T extends TouchableOpacityProps | TouchableWithoutFeedbackProps | TouchableHighlightProps>(WrappedComponent: ComponentType<PropsWithOptionalChildren<T>>): React.FC<PropsWithOptionalChildren<T> & ExtendedProps>;
export {};
