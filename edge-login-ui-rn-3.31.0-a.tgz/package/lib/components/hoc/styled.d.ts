import * as React from 'react';
import { ImageStyle, StyleProp, TextStyle, ViewStyle } from 'react-native';
import { Theme } from '../services/ThemeContext';
interface StyleProps {
    style?: StyleProp<any>;
}
type ValidStyles = ImageStyle | TextStyle | ViewStyle;
type Styler<Props> = ValidStyles | ((theme: Theme) => ValidStyles | ((props: Props) => ValidStyles | ValidStyles[]));
/**
 * Creates a styled component using a `styler` parameter. The `styler` can be the
 * styles itself, a function with the current theme and component props as
 * curried arguments (e.g. `theme => props => styles` or `theme => styles`).
 * The styles are cached when no `props` parameter is required by the `styler`.
 *
 * **Example Usage**
 *
 * ```
 * const Colorful = styled(Text)({ fontWeight: 'Red' })
 * const Themed = styled(Text)(theme => ({ color: theme.color }))
 * const Dynamic = styled(Text)(theme => props => ({ color: props.color ?? theme.color }))
 * const DynamicSansTheme = styled(Text)(_theme => props => ({ color: props.color }))
 * ```
 */
export declare function styled<BaseProps extends StyleProps>(Component: React.ComponentType<BaseProps>): <Props extends object>(styler: Styler<Props>) => React.ComponentType<Omit<BaseProps, "style"> & Props>;
export declare function styledWithRef<Ref, BaseProps extends StyleProps>(Component: React.ComponentType<BaseProps>): <Props extends object>(styler: Styler<Props>) => React.ForwardRefExoticComponent<React.PropsWithoutRef<Omit<BaseProps, "style"> & Props> & React.RefAttributes<Ref>>;
export {};
