import React from 'react';
import { SharedValue } from 'react-native-reanimated';
export interface AnimatedIconProps {
    accessible?: boolean;
    color?: SharedValue<string>;
    size?: SharedValue<number>;
}
export type AnimatedIconComponent = React.FunctionComponent<AnimatedIconProps>;
export interface IconProps {
    accessible?: boolean;
    color?: string;
    size?: number;
}
export type IconComponent = React.FunctionComponent<IconProps>;
export declare function EyeIconAnimated(props: AnimatedIconProps & {
    off: boolean;
}): JSX.Element;
export declare const CloseIcon: IconComponent;
export declare const CloseIconAnimated: AnimatedIconComponent;
export declare const SearchIcon: IconComponent;
export declare const SearchIconAnimated: AnimatedIconComponent;
