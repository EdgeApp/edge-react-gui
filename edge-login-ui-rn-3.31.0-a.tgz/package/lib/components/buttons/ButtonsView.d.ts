/**
 * IMPORTANT: Changes in this file MUST be synced between edge-react-gui and
 * edge-login-ui-rn!
 */
import * as React from 'react';
export interface ButtonInfo {
    label: string;
    onPress: () => void | Promise<void>;
    disabled?: boolean;
    spinner?: boolean;
    testID?: string;
    animDistanceStart?: number;
}
export interface ButtonsViewProps {
    absolute?: boolean;
    primary?: ButtonInfo;
    secondary?: ButtonInfo;
    /** @deprecated - Create a separate component instead for these weird one-off cases */
    secondary2?: ButtonInfo;
    tertiary?: ButtonInfo;
    layout?: 'row' | 'column'
    /** @deprecated - Create `SoloButton` instead */
     | 'solo';
    /** @deprecated Start just creating new components instead of extending this prop. Previously: What kind of component this ButtonsView lives on. Affects margins. */
    parentType?: 'scene' | 'modal';
    animDistanceStart?: number;
}
/**
 * A consistently styled view for displaying button layouts.
 */
export declare const ButtonsView: React.MemoExoticComponent<({ absolute, primary, secondary, secondary2, tertiary, layout, parentType, animDistanceStart }: ButtonsViewProps) => JSX.Element>;
/** @deprecated - Shouldn't use this export post-UI4 transition once all our layouts have been codified into button layout components. */
export declare const StyledButtonContainer: React.ComponentType<Omit<import("react-native").ViewProps, "style"> & {
    absolute?: boolean | undefined;
    layout: 'row' | 'column' | 'solo';
    parentType?: "modal" | "scene" | undefined;
}>;
