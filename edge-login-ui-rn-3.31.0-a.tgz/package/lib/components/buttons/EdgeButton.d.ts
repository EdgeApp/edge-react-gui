/**
 * IMPORTANT: Changes in this file MUST be synced between edge-react-gui and
 * edge-login-ui-rn!
 */
import * as React from 'react';
export type EdgeButtonType = 'primary' | 'secondary' | 'tertiary' | 'destructive';
interface Props {
    children?: React.ReactNode;
    onPress?: () => void | Promise<void>;
    disabled?: boolean;
    label?: string;
    layout?: 'row' | 'column' | 'solo' | 'fullWidth';
    spinner?: boolean;
    type?: EdgeButtonType;
    mini?: boolean;
    /** @deprecated - Shouldn't use this post-UI4 transition */
    marginRem?: number[] | number;
    testID?: string;
}
/**
 * A stylized button with 0 outside margins by default.
 * - Typically to be used as a child of ButtonsViewUi4.
 * - NOT meant to be used on its own outside of ButtonsViewUi4 unless layout='solo'
 */
export declare function EdgeButton(props: Props): React.ReactElement | null;
export {};
