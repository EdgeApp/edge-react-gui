/// <reference types="react" />
import { EdgeAccount, EdgeContext } from 'edge-core-js';
import { OnLogEvent, OnPerfEvent } from './publicTypes';
interface Props {
    account: EdgeAccount;
    context: EdgeContext;
    onComplete: () => void;
    onLogEvent?: OnLogEvent;
    onPerfEvent?: OnPerfEvent;
}
export declare function ChangePasswordScreen(props: Props): JSX.Element;
export {};
