/// <reference types="react" />
import { EdgeAccount, EdgeContext } from 'edge-core-js';
import { Branding } from '../../types/Branding';
import { OnLogEvent, OnPerfEvent } from './publicTypes';
interface Props {
    account: EdgeAccount;
    branding: Branding;
    context: EdgeContext;
    onComplete: () => void;
    onLogEvent: OnLogEvent;
    onPerfEvent?: OnPerfEvent;
}
export declare function PasswordRecoveryScreen(props: Props): JSX.Element;
export {};
