/// <reference types="react" />
import { EdgeAccount, EdgeContext, OtpError } from 'edge-core-js';
import { Branding } from '../../types/Branding';
import { OnLogEvent, OnPerfEvent } from './publicTypes';
interface Props {
    account: EdgeAccount;
    branding: Branding;
    context: EdgeContext;
    otpError: OtpError;
    onComplete: () => void;
    onLogEvent?: OnLogEvent;
    onPerfEvent?: OnPerfEvent;
}
export declare function OtpRepairScreen(props: Props): JSX.Element;
export {};
