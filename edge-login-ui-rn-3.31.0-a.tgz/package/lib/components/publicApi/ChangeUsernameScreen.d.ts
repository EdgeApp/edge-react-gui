/// <reference types="react" />
import { EdgeAccount, EdgeContext } from 'edge-core-js';
import { OnLogEvent, OnPerfEvent } from './publicTypes';
interface Props {
    account: EdgeAccount;
    context: EdgeContext;
    password: string;
    onComplete: () => void;
    onLogEvent?: OnLogEvent;
    onPerfEvent?: OnPerfEvent;
}
/**
 * A standalone screen for changing a username that can be mounted independently.
 * This component handles the username availability check and completes immediately
 * after username change.
 */
export declare function ChangeUsernameScreen(props: Props): JSX.Element;
export {};
