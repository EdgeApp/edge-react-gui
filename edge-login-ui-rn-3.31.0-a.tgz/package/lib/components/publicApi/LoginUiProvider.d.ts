import * as React from 'react';
import { Theme } from '../../types/Theme';
/**
 * We use this context to determine if `LoginUiProvider` is mounted, and whether
 * we are on mobile or desktop.
 */
export declare const loginUiContext: React.Context<{
    hasProvider: boolean;
    isDesktop: boolean;
}>;
interface Props {
    themeOverride?: Theme;
    isDesktop?: boolean;
    children: React.ReactNode;
}
/**
 * Provides modals and other services for the login UI.
 * In the future, this will be our injection point for branding &
 * theme customizations.
 */
declare function LoginUiProviderComponent(props: Props): JSX.Element;
export declare const LoginUiProvider: React.MemoExoticComponent<typeof LoginUiProviderComponent>;
export declare function MaybeProvideLoginUi(props: {
    children: JSX.Element;
}): JSX.Element;
export {};
