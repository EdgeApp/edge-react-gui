import { EdgeAccount } from 'edge-core-js';
export type BiometryType = 'FaceID' | 'TouchID' | false;
export type InitialRouteName = 'login' | 'login-password'
/** @deprecated - No longer used. Same behavior as login-password. */
 | 'login-password-light' | 'new-account' | 'new-light-account';
/** @deprecated - No longer used. Light/full account experiment concluded in
 * favor of light account. */
export type CreateAccountType = 'full' | 'light';
/**
 * Subset of AppConfig from https://github.com/EdgeApp/edge-react-gui/blob/develop/src/types/types.ts
 * This MUST always maintain as a subset
 */
export interface AppConfig {
    supportEmail: string;
    termsOfServiceSite: string;
}
export interface NotificationOptIns {
    ignoreMarketing: boolean;
    ignorePriceChanges: boolean;
}
export interface NotificationPermissionsInfo {
    isNotificationBlocked: boolean;
    notificationOptIns: NotificationOptIns;
}
export interface NotificationPermissionReminderOptions {
    readonly appName?: string;
    readonly onLogEvent?: OnLogEvent;
    readonly onNotificationPermit?: OnNotificationPermit;
}
/**
 * @deprecated This will not be provided in `fastLogin` mode.
 * Use `getSupportedBiometryType` and `touchIdEnabled` to learn these values.
 */
export interface TouchIdInfo {
    isTouchSupported: boolean;
    isTouchEnabled: boolean;
}
export interface ExperimentConfig {
}
export declare const asExperimentConfig: import("cleaners").ObjectCleaner<ExperimentConfig>;
export type PerfEvent = {
    name: 'passwordLoginBegin';
} | {
    name: 'passwordLoginEnd';
    error?: unknown;
} | {
    name: 'pinLoginBegin';
} | {
    name: 'pinLoginEnd';
    error?: unknown;
};
export type TrackingEventName = 'Password_Login_Create_Account' | 'Password_Login_Forgot_Password' | 'Pasword_Login' | 'Permission_Modal_Notification_Enable' | 'Pin_Login' | 'Recovery_Token_Submit' | 'Recovery_Username_Failure' | 'Recovery_Username_Success' | 'Backup_Username_Available' | 'Backup_Password_Valid' | 'Backup_Terms_Agree_and_Create_User' | 'Backup_Review_Done' | 'Signup_Captcha_Failed' | 'Signup_Captcha_Passed' | 'Signup_Captcha_Shown' | 'Signup_Captcha_Quit' | 'Signup_Username_Available' | 'Signup_Password_Valid' | 'Signup_PIN_Valid' | 'Signup_Terms_Agree_and_Create_User' | 'Signup_Create_Light_Account' | 'Signup_Review_Done' | 'Signup_Create_Account' | 'Signup_Signin' | 'Signup_Welcome_Next';
export interface TrackingValues {
    error?: unknown | string;
}
export type OnComplete = () => void;
export type OnLogEvent = (event: TrackingEventName, values?: TrackingValues) => void;
export type OnLogin = (account: EdgeAccount, 
/**
 * @deprecated This will not be provided in `fastLogin` mode
 * Use `getSupportedBiometryType` and `touchIdEnabled` to learn these values.
 */
touchIdInfo?: TouchIdInfo) => void;
export type OnNotificationPermit = (settings: NotificationPermissionsInfo) => void;
export type OnPerfEvent = (event: PerfEvent) => void;
