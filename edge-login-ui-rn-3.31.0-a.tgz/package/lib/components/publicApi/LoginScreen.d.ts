/// <reference types="react" />
import { EdgeAccountOptions, EdgeContext } from 'edge-core-js';
import { ParentButton } from '../../types/Branding';
import { AppConfig, ExperimentConfig, InitialRouteName, OnComplete, OnLogEvent, OnLogin, OnNotificationPermit, OnPerfEvent } from './publicTypes';
interface Props {
    context: EdgeContext;
    /**
     * Options passed to the core login methods.
     */
    accountOptions: EdgeAccountOptions;
    /**
     * Skip all post-login preparation steps.
     *
     * The goal is to display the main application as quickly as possible.
     * Then, once the app is ready, several steps can happen in the background:
     *
     * - `prepareTouchId` to ensure the account can log in with biometrics.
     * - `showNotificationPermissionReminder` to request permissions,
     *   (or the app can provide its own reminder).
     * - `showOtpReminder` to encourage the user to set up 2fa,
     *   (or the app can provide its own reminder).
     * - `watchSecurityAlerts` to check for incoming login requests,
     *   followed by showing the `SecurityAlertsScreen` if detected.
     *
     * If you do not pass the `fastLogin` flag, edge-login-ui-rn itself
     * will perform these steps, which can delay login by several seconds
     * on slower phones.
     */
    fastLogin?: boolean;
    forceLightAccountCreate?: boolean;
    /**
     * The user to select, if present on the device.
     * Get this from `EdgeContext.localUsers`
     */
    initialLoginId?: string;
    /**
     * Which scene to begin with.
     */
    initialRoute?: InitialRouteName;
    /**
     * Pass a recoveryKey from the user's email to trigger recovery login.
     */
    recoveryLogin?: string;
    appId?: string;
    appName?: string;
    landingScreenText?: string;
    parentButton?: ParentButton;
    primaryLogo?: any;
    primaryLogoCallback?: () => void;
    /** Contains the terms of service URL */
    appConfig?: AppConfig;
    /**  Behavior and appearance management flags, for A/B testing. */
    experimentConfig?: ExperimentConfig;
    /**
     * Called when the user navigates back past the initialRoute if it was set.
     */
    onComplete?: OnComplete;
    /**
     * Called when the login completes.
     */
    onLogin: OnLogin;
    /**
     * Generic Login UI interaction events.
     */
    onPerfEvent?: OnPerfEvent;
    /**
     * Records events for analytics.
     */
    onLogEvent?: OnLogEvent;
    /**
     * Called at login.
     *
     * @deprecated Pass `fastLogin` instead, and then perform
     * your custom permissions logic after receiving `onLogin`.
     */
    customPermissionsFunction?: () => void;
    /**
     * @deprecated Use the LoginUiProvider component for theming.
     */
    fontDescription?: {
        regularFontFamily: string;
        headingFontFamily?: string;
    };
    /**
     * Called when the user makes a choice from RequestPermissionsModal.
     *
     * @deprecated Use `fastLogin` mode instead.
     */
    onNotificationPermit?: OnNotificationPermit;
    /**
     * Do not show the OTP reminder during login.
     *
     * @deprecated Pass `fastLogin` instead
     */
    skipOtpReminder?: boolean;
    /**
     * Do not show the security alerts screen during login.
     *
     * @deprecated Pass `fastLogin` instead.
     */
    skipSecurityAlerts?: boolean;
    /**
     * The username to select, if present on the device.
     *
     * @deprecated Use initialLoginId instead.
     */
    username?: string;
}
export declare function LoginScreen(props: Props): JSX.Element;
export {};
