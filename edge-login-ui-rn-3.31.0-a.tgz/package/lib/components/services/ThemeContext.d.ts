/// <reference types="react" />
import { cacheStyles } from 'react-native-patina';
import { Theme } from '../../types/Theme';
export type { Theme };
export { cacheStyles };
/**
 * Utility for declaring `withTheme` components.
 */
export interface ThemeProps {
    theme: Theme;
}
export declare const ThemeProvider: (props: import("react-native-patina").ThemeProviderProps) => JSX.Element, useTheme: () => Theme, withTheme: <Props extends {
    theme: Theme;
}>(Component: import("react").ComponentType<Props>) => (props: "theme" extends keyof Props ? Pick<Props, Exclude<keyof Props, keyof Props & "theme">> : Props) => JSX.Element, changeTheme: (theme: Theme) => void, getTheme: () => Theme, watchTheme: (callback: import("react-native-patina").WatchCallback<Theme>) => import("react-native-patina").Unsubscribe;
/**
 * Changes just the font.
 */
export declare function changeFont(regularFontFamily: string, headingFontFamily: string): void;
