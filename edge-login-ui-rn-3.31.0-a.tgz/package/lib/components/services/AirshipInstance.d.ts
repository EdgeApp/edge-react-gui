export declare const Airship: import("react-native-airship").Airship;
/**
 * Shows an error alert to the user.
 * Used when some user-requested operation fails.
 */
export declare function showError(error: unknown): void;
/**
 * Shows an error warning to the user.
 * Used when some user-requested operation succeeds but with a warning.
 */
export declare function showWarning(message: string): void;
/**
 * Shows a message to the user.
 * Used when some user-requested operation succeeds.
 */
export declare function showToast(message: string): void;
