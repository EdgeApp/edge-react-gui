import * as React from 'react';
import { Store } from 'redux';
import { RootState } from '../../reducers/RootReducer';
import { Action, Dispatch, GetState, Imports } from '../../types/ReduxTypes';
interface Props {
    children?: React.ReactNode;
    initialAction: Action | ((dispatch: Dispatch, getState: GetState, i: Imports) => unknown);
    imports: Imports;
}
/**
 * Consolidates our Redux setup logic into one place.
 */
export declare class ReduxStore extends React.Component<Props> {
    store: Store<RootState>;
    constructor(props: Props);
    componentDidUpdate(prev: Props): void;
    render(): JSX.Element;
}
export {};
