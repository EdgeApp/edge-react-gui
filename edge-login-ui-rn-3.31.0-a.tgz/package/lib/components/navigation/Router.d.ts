/// <reference types="react" />
import { Branding } from '../../types/Branding';
interface Props {
    branding: Branding;
}
export declare function Router(props: Props): JSX.Element;
export {};
