/// <reference types="react" />
export declare const isBlurDisabled: boolean;
/** A blur background WITH rounded corners, used for most components */
export declare const BlurBackground: () => JSX.Element | null;
/** A blur background WITHOUT rounded corners. For the scene header/footer */
export declare const BlurBackgroundNoRoundedCorners: () => JSX.Element | null;
