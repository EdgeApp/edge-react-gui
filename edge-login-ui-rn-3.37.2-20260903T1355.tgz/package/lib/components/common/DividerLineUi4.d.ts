import * as React from 'react';
import type { GradientColors } from '../../types/Theme';
interface Props {
    /** Extend to the right outside of the container. For scene-level usage. */
    extendRight?: boolean;
    /** @deprecated Only to be used during the UI4 transition */
    marginRem?: number[] | number;
    /** Unused by current Edge themes, but supported for third-party integrations. */
    colors?: GradientColors;
}
/**
 * A simple horizontal divider line for separating content sections.
 * Uses the theme's thinLineWidth and lineDivider color for consistent styling.
 */
export declare const DividerLineUi4: (props: Props) => React.ReactElement;
export {};
