/// <reference types="react" />
import { EdgeAccount } from 'edge-core-js';
import { Branding } from '../../../types/Branding';
import { SceneProps } from '../../../types/routerTypes';
export interface NewAccountUsernameParams {
    password?: string;
    pin?: string;
    username?: string;
}
export interface UpgradeUsernameParams {
    account: EdgeAccount;
    password?: string;
    username?: string;
}
interface Props {
    branding: Branding;
    initUsername?: string;
    title?: string;
    warningMessage?: string;
    onBack?: () => void;
    onNext: (username: string) => void | Promise<void>;
}
export declare const ChangeUsernameComponent: (props: Props) => JSX.Element;
/**
 * The username creation scene for new accounts.
 */
interface NewAccountUsernameProps extends SceneProps<'newAccountUsername'> {
    branding: Branding;
}
export declare const NewAccountUsernameScene: (props: NewAccountUsernameProps) => JSX.Element;
/**
 * The change username scene for (light) accounts.
 */
interface UpgradeUsernameProps extends SceneProps<'upgradeUsername'> {
    branding: Branding;
}
export declare const UpgradeUsernameScene: (props: UpgradeUsernameProps) => JSX.Element;
export {};
