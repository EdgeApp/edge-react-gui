import React from 'react';
import { SharedValue } from 'react-native-reanimated';
import AntDesignIcon from 'react-native-vector-icons/AntDesign';
export interface AnimatedIconProps {
    accessible?: boolean;
    color?: SharedValue<string>;
    size?: SharedValue<number>;
}
export type AnimatedIconComponent = React.FunctionComponent<AnimatedIconProps>;
type IconStyle = React.ComponentProps<typeof AntDesignIcon>['style'];
export interface IconProps {
    accessible?: boolean;
    color?: string;
    size?: number;
    style?: IconStyle;
}
export type IconComponent = React.FunctionComponent<IconProps>;
export declare function EyeIconAnimated(props: AnimatedIconProps & {
    off: boolean;
}): JSX.Element;
export declare const ChevronLeftAnimated: AnimatedIconComponent;
export declare const ChevronUpIcon: IconComponent;
export declare const ChevronDownIcon: IconComponent;
export declare const ChevronLeftIcon: IconComponent;
export declare const ChevronRightIcon: IconComponent;
export declare const CloseIcon: IconComponent;
export declare const CloseIconAnimated: AnimatedIconComponent;
export declare const SearchIcon: IconComponent;
export declare const SearchIconAnimated: AnimatedIconComponent;
export {};
