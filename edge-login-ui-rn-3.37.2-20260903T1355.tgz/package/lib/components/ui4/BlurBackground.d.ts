/**
 * IMPORTANT: Changes in this file MUST be synced with edge-react-gui!
 */
import React from 'react';
export declare const isBlurDisabled: boolean;
/** Owns the blur-target ref. Mounted by LoginUiProvider above both the
 * target and the Airship layer whose modals sample it. */
export declare function BlurTargetProvider(props: {
    children: React.ReactNode;
}): React.ReactElement;
/** Marks its children as the content blur surfaces sample. Wraps the app
 * content, NOT the modal layer - a modal must not sample itself. */
export declare function BlurTarget(props: {
    children: React.ReactNode;
}): React.ReactElement;
/** The Android 12+ blur: expo-blur's Dimezis 3 backend, which works under
 * the new architecture but needs the BlurTarget above. Falls back to a plain
 * tint when no target is mounted. */
export declare const AndroidBlur: (props: {
    rounded?: boolean;
}) => React.ReactElement;
export declare const BlurBackground: () => React.ReactElement | null;
