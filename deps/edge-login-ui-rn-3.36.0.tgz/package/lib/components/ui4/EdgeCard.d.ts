import * as React from 'react';
import { LinearGradientProps } from 'react-native-linear-gradient';
interface Props {
    overlay?: React.ReactNode;
    children: React.ReactNode | React.ReactNode[];
    gradientBackground?: LinearGradientProps;
    nodeBackground?: React.ReactNode;
    /** @deprecated Only to be used during the UI4 transition */
    marginRem?: number[] | number;
    /** @deprecated Only to be used during the UI4 transition */
    paddingRem?: number[] | number;
    fill?: boolean;
    sections?: boolean;
    testID?: string;
    onClose?: () => Promise<void> | void;
    onLongPress?: () => Promise<void> | void;
    onPress?: () => Promise<void> | void;
}
/**
 * Rounded card
 *
 * sections: Automatically adds horizontal dividers between each child, aligned
 * in a column layout. Adds no dividers if only one child is given.
 *
 * gradientBackground/nodeBackground: For specifying a complex background
 * that can include embedded images or any other component.
 *
 * onClose: If specified, adds a close button
 */
export declare const EdgeCard: (props: Props) => JSX.Element | null;
export {};
