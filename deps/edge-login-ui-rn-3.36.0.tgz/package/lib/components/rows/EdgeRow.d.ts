import * as React from 'react';
export type RowActionIcon = 'none' | 'touchable';
interface Props {
    body?: string;
    children?: React.ReactNode;
    error?: boolean;
    icon?: React.ReactNode;
    loading?: boolean;
    maximumHeight?: 'small' | 'medium' | 'large';
    rightButtonType?: RowActionIcon;
    title?: string;
    testID?: string;
    onLongPress?: () => Promise<void> | void;
    onPress?: () => Promise<void> | void;
    /** @deprecated Only to be used during the UI4 transition */
    marginRem?: number[] | number;
}
export declare const EdgeRow: React.FC<Props>;
export {};
