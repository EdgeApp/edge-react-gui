import * as React from 'react';
import { TextProps } from 'react-native';
export declare const UnscaledText: React.FC<TextProps>;
