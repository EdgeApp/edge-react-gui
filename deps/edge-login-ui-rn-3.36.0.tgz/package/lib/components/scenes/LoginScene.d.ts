import * as React from 'react';
import { Branding } from '../../types/Branding';
import { SceneProps } from '../../types/routerTypes';
export interface LoginParams {
    loginId?: string;
    username?: string;
    /**
     * Start in the password flavor even when the selected user has PIN/biometric
     * enabled (used by the `login-password` initial route and the flows that fall
     * back to password entry).
     */
    passwordOnly?: boolean;
}
interface Props extends SceneProps<'login'> {
    branding: Branding;
}
export declare const LoginScene: (props: Props) => React.ReactElement;
export {};
