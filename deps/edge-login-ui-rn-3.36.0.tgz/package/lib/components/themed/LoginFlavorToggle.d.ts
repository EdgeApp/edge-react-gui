import * as React from 'react';
export type LoginFlavor = 'password' | 'pin';
interface Props {
    flavor: LoginFlavor;
    /**
     * When false the PIN/biometric pill is shown greyed-out. It still calls
     * `onSelectPin` so the parent can surface a toast explaining why it is
     * unavailable.
     */
    pinEnabled: boolean;
    onSelectPassword: () => void;
    onSelectPin: () => void;
}
/**
 * A two-segment pill toggle that switches the login scene between its password
 * and PIN/biometric flavors.
 */
export declare const LoginFlavorToggle: React.FC<Props>;
export {};
