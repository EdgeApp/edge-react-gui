import * as React from 'react';
import { TextStyle } from 'react-native';
import { ThemeProps } from '../services/ThemeContext';
interface Props {
    textStyle: TextStyle;
    children: React.ReactNode;
    value: boolean;
    ellipsizeMode?: 'head' | 'middle' | 'tail' | 'clip';
    numberOfLines?: number;
    disabled?: boolean;
    marginRem?: number[] | number;
    onChange: (value: boolean) => void;
    disableFontScaling?: boolean;
}
export declare const Checkbox: (props: Pick<Props & ThemeProps, keyof Props>) => JSX.Element;
export {};
