import * as React from 'react';
interface Props {
    children: React.ReactNode | React.ReactNode[];
    extendRight?: boolean;
    /** @deprecated Only to be used during the UI4 transition */
    marginRem?: number[] | number;
    /** @deprecated Only to be used during the UI4 transition */
    dividerMarginRem?: number[] | number;
}
/**
 * View that automatically adds horizontal dividers between each child, aligned
 * in a column layout. Adds no dividers if only one child is given.
 *
 * wideSpacing is meant for sectioning out a scene where more spacing is needed
 * between sections.
 */
export declare const SectionView: (props: Props) => React.ReactElement | null;
export {};
