import * as React from 'react';
import { AirshipBridge } from 'react-native-airship';
export type LoginHelpResult = 'qr' | 'recovery';
interface Props {
    bridge: AirshipBridge<LoginHelpResult | undefined>;
}
/**
 * The "Trouble Signing in?" modal. Folds the QR-code login and the password
 * recovery token entry into a single help sheet, resolving with the option the
 * user selected (or `undefined` if they dismissed it). The options reuse the
 * shared EdgeCard + EdgeRow kit so they match the card rows used elsewhere in
 * the app.
 */
export declare const LoginHelpModal: React.FC<Props>;
export {};
