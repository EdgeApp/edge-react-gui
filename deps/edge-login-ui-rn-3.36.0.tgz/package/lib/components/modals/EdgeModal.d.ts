/**
 * IMPORTANT: Changes in this file MUST be synced between edge-react-gui and
 * edge-login-ui-rn!
 */
import * as React from 'react';
import { AirshipBridge } from 'react-native-airship';
export interface EdgeModalProps<T = unknown> {
    bridge: AirshipBridge<T>;
    /**
     * If a non-string title is provided, it's up to the caller to ensure no close
     * button overlap.
     */
    title?: React.ReactNode;
    children?: React.ReactNode;
    /**
     * Include a scroll area:
     */
    scroll?: boolean;
    /**
     * Gives the box a border:
     */
    warning?: boolean;
    /**
     * Called when the user taps outside the modal or clicks the back button.
     * If this is missing, the modal will not be closable.
     */
    onCancel?: () => void;
}
/**
 * A modal that slides a modal up from the bottom of the screen
 * and dims the rest of the app.
 */
export declare function EdgeModal<T>(props: EdgeModalProps<T>): React.ReactElement;
