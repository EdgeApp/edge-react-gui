export declare const LOGO_BIG: any;
export declare const LOGO_BIG_LIGHT: any;
