"use strict";Object.defineProperty(exports, "__esModule", {value: true}); function _createStarExport(obj) { Object.keys(obj) .filter((key) => key !== "default" && key !== "__esModule") .forEach((key) => { if (exports.hasOwnProperty(key)) { return; } Object.defineProperty(exports, key, {enumerable: true, configurable: true, get: () => obj[key]}); }); }// This file is exported to client apps via NPM.

var _xcleaners = require('@edge.app/x-cleaners');













var _cleaners = require('cleaners');

// Re-export the public attestation verifier + constants so downstream Edge
// services get them from the published package entry (see the build script,
// which also emits ./attestation.js alongside ./types.js).
var _attestation = require('./attestation'); _createStarExport(_attestation);

 const asExposedKey = _cleaners.asObject.call(void 0, {
  pubKeyHash: _cleaners.asString,
  exposed: _cleaners.asBoolean
}); exports.asExposedKey = asExposedKey

 const asDocNotFound = _cleaners.asObject.call(void 0, {
  error: _cleaners.asValue.call(void 0, 'not_found'),
  docId: _cleaners.asString
}); exports.asDocNotFound = asDocNotFound

 const asBulkDbQuery = _cleaners.asObject.call(void 0, {
  docIds: _cleaners.asArray.call(void 0, _cleaners.asString)
}); exports.asBulkDbQuery = asBulkDbQuery

 const asBulkExposedKeyResponse = _cleaners.asObject.call(void 0, {
  docs: _cleaners.asArray.call(void 0, _cleaners.asEither.call(void 0, exports.asExposedKey, exports.asDocNotFound))
}); exports.asBulkExposedKeyResponse = asBulkExposedKeyResponse

/** @deprecated use `asInfoCard` */
 const asAssetStatus = _cleaners.asObject.call(void 0, {
  appId: _cleaners.asOptional.call(void 0, _cleaners.asString),
  appVersions: _cleaners.asOptional.call(void 0, _cleaners.asArray.call(void 0, _cleaners.asString)),
  statusType: _cleaners.asValue.call(void 0, 'warning', 'info'),
  localeStatusTitle: _cleaners.asObject.call(void 0, _cleaners.asString),
  localeStatusBody: _cleaners.asObject.call(void 0, _cleaners.asString),
  iconUrl: _cleaners.asOptional.call(void 0, _cleaners.asString),
  statusUrl: _cleaners.asOptional.call(void 0, _cleaners.asString),
  statusStartIsoDate: _cleaners.asString,
  statusEndIsoDate: _cleaners.asString
}); exports.asAssetStatus = asAssetStatus

/** @deprecated use `asAssetStatus2` */
 const asAssetStatusCards = _cleaners.asObject.call(void 0, _xcleaners.asHealingArray.call(void 0, exports.asAssetStatus)); exports.asAssetStatusCards = asAssetStatusCards

const asNestedDisableMap = _cleaners.asObject.call(void 0, 
  _cleaners.asEither.call(void 0, _cleaners.asBoolean, raw => asNestedDisableMap(raw))
)

const asFiatDirectionInfo = _cleaners.asObject.call(void 0, {
  disablePlugins: asNestedDisableMap
})

// Remote enable/disable config for gift card providers.
// `disablePlugins` is a generic NestedDisableMap keyed by providerId, so it
// works for any present or future provider:
//   { phaze: true }                 // disable the entire provider
//   { phaze: { '12345': true } }    // disable a single brand by productId
//   { bitrefill: true }             // webview provider: whole-provider only
 const asGiftCardInfo = _cleaners.asObject.call(void 0, {
  disablePlugins: asNestedDisableMap
}); exports.asGiftCardInfo = asGiftCardInfo

 const asMangoSelector = _cleaners.asUnknown ; exports.asMangoSelector = asMangoSelector

 const asAssetSpread = _cleaners.asObject.call(void 0, {
  sourcePluginId: _cleaners.asOptional.call(void 0, _cleaners.asString),
  sourceTokenId: _cleaners.asOptional.call(void 0, _cleaners.asString),
  sourceCurrencyCode: _cleaners.asOptional.call(void 0, _cleaners.asString),
  destPluginId: _cleaners.asOptional.call(void 0, _cleaners.asString),
  destTokenId: _cleaners.asOptional.call(void 0, _cleaners.asString),
  destCurrencyCode: _cleaners.asOptional.call(void 0, _cleaners.asString),
  volatilitySpread: _cleaners.asNumber
}); exports.asAssetSpread = asAssetSpread

 const asExchangeInfo = _cleaners.asObject.call(void 0, {
  buy: _cleaners.asMaybe(asFiatDirectionInfo, () => ({
    disablePlugins: {
      myPluginId: true,
      myPluginId2: { myProviderId: true }
    }
  })),
  sell: _cleaners.asMaybe(asFiatDirectionInfo, () => ({
    disablePlugins: {
      myPluginId: true,
      myPluginId2: { myProviderId: true }
    }
  })),
  swap: _cleaners.asMaybe.call(void 0, 
    _cleaners.asObject.call(void 0, {
      disableAssets: _cleaners.asObject.call(void 0, {
        source: _cleaners.asArray.call(void 0, _cleaners.asUnknown),
        destination: _cleaners.asArray.call(void 0, _cleaners.asUnknown)
      }),
      disablePlugins: _cleaners.asOptional.call(void 0, _cleaners.asObject.call(void 0, _cleaners.asBoolean)),
      plugins: _cleaners.asObject.call(void 0, {
        thorchain: _cleaners.asOptional.call(void 0, 
          _cleaners.asObject.call(void 0, {
            perAssetSpread: _cleaners.asArray.call(void 0, exports.asAssetSpread),
            perAssetSpreadStreaming: _cleaners.asOptional.call(void 0, _cleaners.asArray.call(void 0, exports.asAssetSpread)),
            volatilitySpread: _cleaners.asNumber,
            volatilitySpreadStreaming: _cleaners.asOptional.call(void 0, _cleaners.asNumber),
            likeKindVolatilitySpread: _cleaners.asNumber,
            likeKindVolatilitySpreadStreaming: _cleaners.asOptional.call(void 0, _cleaners.asNumber),
            daVolatilitySpread: _cleaners.asNumber,
            midgardServers: _cleaners.asArray.call(void 0, _cleaners.asString),
            affiliateFeeBasis: _cleaners.asOptional.call(void 0, _cleaners.asString, '50'),
            nineRealmsServers: _cleaners.asOptional.call(void 0, _cleaners.asArray.call(void 0, _cleaners.asString)),
            streamingInterval: _cleaners.asOptional.call(void 0, _cleaners.asNumber, 10),
            streamingQuantity: _cleaners.asOptional.call(void 0, _cleaners.asNumber, 10),
            thorSwapServers: _cleaners.asOptional.call(void 0, _cleaners.asArray.call(void 0, _cleaners.asString)),
            thornodeServers: _cleaners.asOptional.call(void 0, _cleaners.asArray.call(void 0, _cleaners.asString)), // https://thornode.ninerealms.com
            thornodeServersWithPath: _cleaners.asOptional.call(void 0, _cleaners.asArray.call(void 0, _cleaners.asString)) // https://thornode.ninerealms.com/thorchain
          })
        ),
        thorchainda: _cleaners.asOptional.call(void 0, 
          _cleaners.asObject.call(void 0, {
            daVolatilitySpread: _cleaners.asOptional.call(void 0, _cleaners.asNumber),
            affiliateFeeBasis: _cleaners.asOptional.call(void 0, _cleaners.asString),
            thornodeServers: _cleaners.asOptional.call(void 0, _cleaners.asArray.call(void 0, _cleaners.asString)),
            thorSwapServers: _cleaners.asOptional.call(void 0, _cleaners.asArray.call(void 0, _cleaners.asString)),
            thornodeServersWithPath: _cleaners.asOptional.call(void 0, _cleaners.asArray.call(void 0, _cleaners.asString))
          })
        ),
        swapkit: _cleaners.asOptional.call(void 0, 
          _cleaners.asObject.call(void 0, {
            daVolatilitySpread: _cleaners.asOptional.call(void 0, _cleaners.asNumber),
            affiliateFeeBasis: _cleaners.asOptional.call(void 0, _cleaners.asString),
            thornodeServers: _cleaners.asOptional.call(void 0, _cleaners.asArray.call(void 0, _cleaners.asString)),
            thorSwapServers: _cleaners.asOptional.call(void 0, _cleaners.asArray.call(void 0, _cleaners.asString)),
            thornodeServersWithPath: _cleaners.asOptional.call(void 0, _cleaners.asArray.call(void 0, _cleaners.asString))
          })
        ),
        mayaprotocol: _cleaners.asOptional.call(void 0, 
          _cleaners.asObject.call(void 0, {
            perAssetSpread: _cleaners.asArray.call(void 0, exports.asAssetSpread),
            perAssetSpreadStreaming: _cleaners.asOptional.call(void 0, _cleaners.asArray.call(void 0, exports.asAssetSpread)),
            volatilitySpread: _cleaners.asNumber,
            volatilitySpreadStreaming: _cleaners.asOptional.call(void 0, _cleaners.asNumber),
            likeKindVolatilitySpread: _cleaners.asNumber,
            likeKindVolatilitySpreadStreaming: _cleaners.asOptional.call(void 0, _cleaners.asNumber),
            midgardServers: _cleaners.asArray.call(void 0, _cleaners.asString),
            affiliateFeeBasis: _cleaners.asOptional.call(void 0, _cleaners.asString),
            streamingInterval: _cleaners.asOptional.call(void 0, _cleaners.asNumber),
            streamingQuantity: _cleaners.asOptional.call(void 0, _cleaners.asNumber),
            thornodeServersWithPath: _cleaners.asOptional.call(void 0, _cleaners.asArray.call(void 0, _cleaners.asString))
          })
        )
      })
    }),
    () => ({
      disableAssets: {
        source: [],
        destination: []
      },
      disablePlugins: {},
      plugins: {
        thorchain: undefined,
        thorchainda: undefined,
        swapkit: undefined,
        mayaprotocol: undefined
      }
    })
  )
}); exports.asExchangeInfo = asExchangeInfo

 const asImageGradientBackground = _cleaners.asObject.call(void 0, {
  backgroundGradientColors: _cleaners.asArray.call(void 0, _cleaners.asString),
  backgroundGradientStart: _cleaners.asObject.call(void 0, {
    x: _cleaners.asNumber,
    y: _cleaners.asNumber
  }),
  backgroundGradientEnd: _cleaners.asObject.call(void 0, {
    x: _cleaners.asNumber,
    y: _cleaners.asNumber
  }),
  imageUri: _cleaners.asString
}); exports.asImageGradientBackground = asImageGradientBackground

 const asSurveyOptions = _xcleaners.asHealingArray.call(void 0, _cleaners.asString); exports.asSurveyOptions = asSurveyOptions
 const asInstallSurvey = _cleaners.asObject.call(void 0, {
  surveyOptions: exports.asSurveyOptions
}); exports.asInstallSurvey = asInstallSurvey

 const asSurveyOptions2 = _cleaners.asObject.call(void 0, {
  ads: _cleaners.asArray.call(void 0, _cleaners.asObject.call(void 0, _cleaners.asString)),
  appStore: _cleaners.asArray.call(void 0, _cleaners.asObject.call(void 0, _cleaners.asString)),
  article: _cleaners.asArray.call(void 0, _cleaners.asObject.call(void 0, _cleaners.asString)),
  inPerson: _cleaners.asArray.call(void 0, _cleaners.asObject.call(void 0, _cleaners.asString)),
  referral: _cleaners.asArray.call(void 0, _cleaners.asObject.call(void 0, _cleaners.asString)),
  search: _cleaners.asArray.call(void 0, _cleaners.asObject.call(void 0, _cleaners.asString)),
  social: _cleaners.asArray.call(void 0, _cleaners.asObject.call(void 0, _cleaners.asString))
}); exports.asSurveyOptions2 = asSurveyOptions2
 const asInstallSurvey2 = _cleaners.asObject.call(void 0, {
  surveyOptions2: exports.asSurveyOptions2
}); exports.asInstallSurvey2 = asInstallSurvey2

 const asPluginPromotion = _cleaners.asObject.call(void 0, {
  pluginType: _cleaners.asValue.call(void 0, 'buy', 'sell', 'swap'),
  pluginIds: _cleaners.asOptional.call(void 0, _cleaners.asArray.call(void 0, _cleaners.asString)),
  preferProviders: _cleaners.asOptional.call(void 0, _cleaners.asArray.call(void 0, _cleaners.asString)),
  providerIds: _cleaners.asOptional.call(void 0, _cleaners.asArray.call(void 0, _cleaners.asString)),
  promoCode: _cleaners.asOptional.call(void 0, _cleaners.asString)
}); exports.asPluginPromotion = asPluginPromotion

 const asInfoCard = _cleaners.asObject.call(void 0, {
  localeMessages: _cleaners.asObject.call(void 0, _cleaners.asString),
  ctaButton: _cleaners.asOptional.call(void 0, 
    _cleaners.asObject.call(void 0, {
      localeLabels: _cleaners.asObject.call(void 0, _cleaners.asString),
      localeUrls: _cleaners.asObject.call(void 0, _cleaners.asString)
    })
  ),
  background: _cleaners.asObject.call(void 0, {
    darkMode: exports.asImageGradientBackground,
    lightMode: exports.asImageGradientBackground
  }),
  countryCodes: _cleaners.asOptional.call(void 0, _cleaners.asArray.call(void 0, _cleaners.asString)),
  excludeCountryCodes: _cleaners.asOptional.call(void 0, _cleaners.asArray.call(void 0, _cleaners.asString)),
  hasLinkedBankMap: _cleaners.asOptional.call(void 0, _cleaners.asObject.call(void 0, _cleaners.asBoolean)),
  exactBuildNum: _cleaners.asOptional.call(void 0, _cleaners.asString),
  minBuildNum: _cleaners.asOptional.call(void 0, _cleaners.asString),
  maxBuildNum: _cleaners.asOptional.call(void 0, _cleaners.asString),
  osTypes: _cleaners.asOptional.call(void 0, _cleaners.asArray.call(void 0, _cleaners.asString)),
  osVersions: _cleaners.asOptional.call(void 0, _cleaners.asArray.call(void 0, _cleaners.asString)),
  startIsoDate: _cleaners.asOptional.call(void 0, _cleaners.asString),
  endIsoDate: _cleaners.asOptional.call(void 0, _cleaners.asString),
  appVersion: _cleaners.asOptional.call(void 0, _cleaners.asString),
  noBalance: _cleaners.asOptional.call(void 0, _cleaners.asBoolean, false),
  dismissable: _cleaners.asOptional.call(void 0, _cleaners.asBoolean, true),
  pluginPromotions: _cleaners.asOptional.call(void 0, _cleaners.asArray.call(void 0, exports.asPluginPromotion)),
  promoId: _cleaners.asOptional.call(void 0, _cleaners.asString)
}); exports.asInfoCard = asInfoCard

 const asPromoCards2 = _xcleaners.asHealingArray.call(void 0, exports.asInfoCard); exports.asPromoCards2 = asPromoCards2
 const asAssetStatusCards2 = _xcleaners.asHealingObject.call(void 0, _xcleaners.asHealingArray.call(void 0, exports.asInfoCard)); exports.asAssetStatusCards2 = asAssetStatusCards2
 const asStakeStatusCards = _xcleaners.asHealingObject.call(void 0, _xcleaners.asHealingArray.call(void 0, exports.asInfoCard)); exports.asStakeStatusCards = asStakeStatusCards
 const asAssetInfoCards = _xcleaners.asHealingObject.call(void 0, _xcleaners.asHealingArray.call(void 0, exports.asInfoCard)); exports.asAssetInfoCards = asAssetInfoCards

 const asAppIdInfo = _cleaners.asObject.call(void 0, {
  appName: _cleaners.asString,
  imageUrl: _cleaners.asOptional.call(void 0, _cleaners.asString),
  hidePoweredBy: _cleaners.asOptional.call(void 0, _cleaners.asBoolean, false),
  lightImageUrl: _cleaners.asOptional.call(void 0, _cleaners.asString),
  darkImageUrl: _cleaners.asOptional.call(void 0, _cleaners.asString)
}); exports.asAppIdInfo = asAppIdInfo
 const asApyValues = _cleaners.asObject.call(void 0, { policies: _cleaners.asObject.call(void 0, _cleaners.asNumber) }); exports.asApyValues = asApyValues
 const asAssetOverrides = _cleaners.asObject.call(void 0, { disable: _cleaners.asObject.call(void 0, _cleaners.asBoolean) }); exports.asAssetOverrides = asAssetOverrides
 const asBlockBook = _cleaners.asObject.call(void 0, _cleaners.asEither.call(void 0, _xcleaners.asHealingArray.call(void 0, _cleaners.asString), _cleaners.asNull)); exports.asBlockBook = asBlockBook

/**
 * List of blog posts to show on home screen
 * @deprecated - Use `asContentPost` instead
 */
 const asBlogPost = _cleaners.asObject.call(void 0, {
  localeTitle: _cleaners.asObject.call(void 0, _cleaners.asString),
  localeBody: _cleaners.asObject.call(void 0, _cleaners.asString),
  /** NOTE: This is for *any* URL associated with this content, not just for blogs. */
  localeBlogUrl: _cleaners.asObject.call(void 0, _cleaners.asString),
  lightImageUrl: _cleaners.asString,
  darkImageUrl: _cleaners.asString
}); exports.asBlogPost = asBlogPost
/** @deprecated - Use `asContentPost` instead */
 const asBlogPosts = _xcleaners.asHealingArray.call(void 0, exports.asBlogPost); exports.asBlogPosts = asBlogPosts

/**
 * Basic content post (videos, blogs, etc) shape.
 *
 * NOTE: `localeBlogUrl` is for *any* CTA URL associated with this content, not
 * just for blogs.
 */
 const asContentPost = _cleaners.asObject.call(void 0, {
  ...exports.asBlogPost.shape,
  countryCodes: _cleaners.asMaybe.call(void 0, _cleaners.asArray.call(void 0, _cleaners.asString), () => []),
  excludeCountryCodes: _cleaners.asMaybe.call(void 0, _cleaners.asArray.call(void 0, _cleaners.asString), () => [])
}); exports.asContentPost = asContentPost
 const asContentPosts = _xcleaners.asHealingArray.call(void 0, exports.asContentPost); exports.asContentPosts = asContentPosts

/**
 * This is the internal data for each of the core plugins.
 */
 const asCorePluginsInternal =
  _cleaners.asObject.call(void 0, _cleaners.asUnknown); exports.asCorePluginsInternal = asCorePluginsInternal




/** Backwards compatiblity prior to genericized ContentPosts type. */
 const asBlogPostGeo = exports.asContentPost; exports.asBlogPostGeo = asBlogPostGeo
 const asBlogPostsGeo = exports.asContentPosts; exports.asBlogPostsGeo = asBlogPostsGeo

const asSemver = (raw) => {
  const str = _cleaners.asString.call(void 0, raw)
  const semverPattern =
    /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?$/
  if (semverPattern.test(str)) {
    return raw
  }
  throw new Error(`Invalid semver string ${str}`)
}

/** Latest app version info */
 const asUpdateVersionMessage = _cleaners.asObject.call(void 0, {
  updateVersion: asSemver,
  localeMessage: _cleaners.asObject.call(void 0, _cleaners.asString)
}); exports.asUpdateVersionMessage = asUpdateVersionMessage
 const asUpdateInfo = _cleaners.asObject.call(void 0, exports.asUpdateVersionMessage); exports.asUpdateInfo = asUpdateInfo

/**
 * The plugin list scene stores its data in JSON files,
 * which have an array of these rows unknown with strings for comments.
 */
const asGuiPluginJsonRow = _cleaners.asObject.call(void 0, {
  // A unique string to identify this particular row:
  id: _cleaners.asString,

  // The plugin to display if we select this item:
  pluginId: _cleaners.asOptional.call(void 0, _cleaners.asString),

  // Optional stuff to add to the plugin URI:
  deepPath: _cleaners.asOptional.call(void 0, _cleaners.asString),
  deepQuery: _cleaners.asOptional.call(void 0, _cleaners.asObject.call(void 0, _cleaners.asEither.call(void 0, _cleaners.asString, _cleaners.asNull))),

  // Optional params to sent to native Fiat Plugins
  paymentType: _cleaners.asOptional.call(void 0, _cleaners.asUnknown),

  // List display options:
  title: _cleaners.asOptional.call(void 0, _cleaners.asString),
  customTitleKey: _cleaners.asOptional.call(void 0, _cleaners.asString),
  description: _cleaners.asOptional.call(void 0, _cleaners.asString),
  partnerIconPath: _cleaners.asOptional.call(void 0, _cleaners.asString),
  paymentTypeLogoKey: _cleaners.asOptional.call(void 0, _cleaners.asString),
  paymentTypes: _cleaners.asOptional.call(void 0, _cleaners.asArray.call(void 0, _cleaners.asString)),
  cryptoCodes: _cleaners.asOptional.call(void 0, _cleaners.asArray.call(void 0, _cleaners.asString)),

  // Filtering & sorting:
  forCountries: _cleaners.asOptional.call(void 0, _cleaners.asArray.call(void 0, _cleaners.asString)),
  forStateProvinces: _cleaners.asOptional.call(void 0, _cleaners.asObject.call(void 0, _cleaners.asArray.call(void 0, _cleaners.asString))),
  notStateProvinces: _cleaners.asOptional.call(void 0, _cleaners.asObject.call(void 0, _cleaners.asArray.call(void 0, _cleaners.asString))),
  forPlatform: _cleaners.asOptional.call(void 0, _cleaners.asString),
  sortIndex: _cleaners.asOptional.call(void 0, _cleaners.asNumber)
})
// asString option is used to place comments in json file

 const asGuiPluginJson =
  _xcleaners.asHealingArray.call(void 0, _cleaners.asEither.call(void 0, _cleaners.asString, asGuiPluginJsonRow)); exports.asGuiPluginJson = asGuiPluginJson
 const asBuySellPlugins = _cleaners.asObject.call(void 0, {
  // If either buy or sell is undefined, fallback to app defaults and purge disk cache
  buy: _cleaners.asOptional.call(void 0, exports.asGuiPluginJson),
  sell: _cleaners.asOptional.call(void 0, exports.asGuiPluginJson)
}); exports.asBuySellPlugins = asBuySellPlugins

 const asEosPrices = _cleaners.asObject.call(void 0, _cleaners.asString); exports.asEosPrices = asEosPrices

/**
 * Common network fee cleaner
 */

 const asFeeRates = _cleaners.asObject.call(void 0, {
  lowFee: _cleaners.asString,
  standardFeeLow: _cleaners.asString,
  standardFeeHigh: _cleaners.asString,
  standardFeeLowAmount: _cleaners.asString,
  standardFeeHighAmount: _cleaners.asString,
  highFee: _cleaners.asString
}); exports.asFeeRates = asFeeRates

/**
 * UTXO specific fees
 */

 const asUtxoFeeRates = _cleaners.asObject.call(void 0, {
  ...exports.asFeeRates.shape,
  lowFeeFudgeFactor: _cleaners.asMaybe.call(void 0, _cleaners.asString),
  standardFeeLowFudgeFactor: _cleaners.asMaybe.call(void 0, _cleaners.asString),
  standardFeeHighFudgeFactor: _cleaners.asMaybe.call(void 0, _cleaners.asString),
  highFeeFudgeFactor: _cleaners.asMaybe.call(void 0, _cleaners.asString)
}); exports.asUtxoFeeRates = asUtxoFeeRates

/**
 * Gas-based Network Fees
 */

 const asEvmBaseFeeMultiplier = _cleaners.asObject.call(void 0, {
  lowFee: _cleaners.asString,
  standardFeeLow: _cleaners.asString,
  standardFeeHigh: _cleaners.asString,
  highFee: _cleaners.asString
}); exports.asEvmBaseFeeMultiplier = asEvmBaseFeeMultiplier


 const asEvmGasLimit = _cleaners.asObject.call(void 0, {
  minGasLimit: _cleaners.asOptional.call(void 0, _cleaners.asString),
  regularTransaction: _cleaners.asString,
  tokenTransaction: _cleaners.asString
}); exports.asEvmGasLimit = asEvmGasLimit


 const asEvmGasPrice = _cleaners.asObject.call(void 0, {
  ...exports.asFeeRates.shape,
  minGasPrice: _cleaners.asOptional.call(void 0, _cleaners.asString)
}); exports.asEvmGasPrice = asEvmGasPrice


 const asGasFeeSettings = _cleaners.asObject.call(void 0, {
  baseFeeMultiplier: _cleaners.asOptional.call(void 0, exports.asEvmBaseFeeMultiplier),
  gasLimit: _cleaners.asOptional.call(void 0, exports.asEvmGasLimit),
  gasPrice: _cleaners.asOptional.call(void 0, exports.asEvmGasPrice),
  minPriorityFee: _cleaners.asOptional.call(void 0, _cleaners.asString)
}); exports.asGasFeeSettings = asGasFeeSettings

 const asEvmBasedFees = _cleaners.asObject.call(void 0, exports.asGasFeeSettings); exports.asEvmBasedFees = asEvmBasedFees


/**
 * Union of all network fee settings
 */
 const asNetworkFee = _cleaners.asEither.call(void 0, exports.asEvmBasedFees, exports.asUtxoFeeRates); exports.asNetworkFee = asNetworkFee
 const asNetworkFees = _cleaners.asObject.call(void 0, exports.asNetworkFee); exports.asNetworkFees = asNetworkFees



 const asFiatPluginPriority = _cleaners.asObject.call(void 0, _cleaners.asObject.call(void 0, _cleaners.asNumber)); exports.asFiatPluginPriority = asFiatPluginPriority

 const asFioAssets = _xcleaners.asHealingObject.call(void 0, 
  _cleaners.asObject.call(void 0, {
    chainCode: _cleaners.asString,
    tokenCodes: _cleaners.asObject.call(void 0, _cleaners.asString)
  })
); exports.asFioAssets = asFioAssets

 const asInfoRollup = _cleaners.asObject.call(void 0, {
  appIdInfo: _cleaners.asObject.call(void 0, exports.asAppIdInfo),
  apyValues: exports.asApyValues,
  assetOverrides: _cleaners.asOptional.call(void 0, exports.asAssetOverrides),
  assetInfoCards: _cleaners.asOptional.call(void 0, exports.asAssetInfoCards),
  assetStatusCards: _cleaners.asOptional.call(void 0, exports.asAssetStatusCards),
  assetStatusCards2: _cleaners.asOptional.call(void 0, exports.asAssetStatusCards2),
  blockBook: exports.asBlockBook,
  blogPosts: _cleaners.asOptional.call(void 0, exports.asBlogPosts),
  blogPostsGeo: _cleaners.asOptional.call(void 0, exports.asBlogPostsGeo),
  buySellPlugins: _cleaners.asOptional.call(void 0, exports.asBuySellPlugins),
  buySellPluginsPatch: _cleaners.asOptional.call(void 0, exports.asBuySellPlugins),
  exchangeInfo: _cleaners.asOptional.call(void 0, exports.asExchangeInfo),
  fiatPluginPriority: _cleaners.asOptional.call(void 0, exports.asFiatPluginPriority),
  fioAssets: _cleaners.asOptional.call(void 0, exports.asFioAssets),
  installSurvey: _cleaners.asOptional.call(void 0, exports.asInstallSurvey),
  installSurvey2: _cleaners.asOptional.call(void 0, exports.asInstallSurvey2),
  networkFees: exports.asNetworkFees,
  promoCards2: _cleaners.asOptional.call(void 0, exports.asPromoCards2),
  rampQuoteFilter: _cleaners.asOptional.call(void 0, _cleaners.asObject.call(void 0, exports.asMangoSelector)),
  giftCardInfo: _cleaners.asOptional.call(void 0, exports.asGiftCardInfo),
  stakeStatusCards: _cleaners.asOptional.call(void 0, exports.asStakeStatusCards),
  updateInfo: _cleaners.asOptional.call(void 0, exports.asUpdateInfo),
  videoPosts: _cleaners.asOptional.call(void 0, exports.asContentPosts),
  appKeys: _cleaners.asOptional.call(void 0, _cleaners.asObject.call(void 0, _cleaners.asUnknown)),
  assuranceLevel: _cleaners.asOptional.call(void 0, _cleaners.asString)
}); exports.asInfoRollup = asInfoRollup























