# Edge Wallet and SDK info server

### Provides various info such as mining fees, server lists, and supported currency/token info

#### Installation

Install Yarn

    https://linuxize.com/post/how-to-install-yarn-on-ubuntu-18-04/

Install Node

    curl -sL https://deb.nodesource.com/setup_10.x -o nodesource_setup.sh
    sudo bash nodesource_setup.sh

Run Yarn

    npm run Install and run CouchDB v3.1 (use apt install process for Ubuntu 18.04)

    https://docs.couchdb.org/en/3.1.0/install/index.html

#### Launch API server

    node lib/indexInfo.js

#### Launch background tasks

    node lib/infoEngines.js

#### Launch API server and rates engine for production


Install pm2 globally

    sudo npm install pm2 -g

Install pm2 log rotation (note: the command is pm2 instead of npm)

    sudo pm2 install pm2-logrotate

Run as standard user

    pm2 start pm2.json

#### Restart, stop, delete service

Control pm2

    pm2 stop infoServer
    pm2 restart infoServer
    pm2 delete infoServer

    pm2 stop infoEngine
    pm2 restart infoEngine
    pm2 delete infoEngine

Launch pm2 on restart

    pm2 startup
    pm2 save

#### Monitor logs and status

    pm2 monit
    pm2 logs <infoServer|infoEngine|'all'>

Please see our [Caddy setup documentation](./docs/caddySetup.md) for details.
