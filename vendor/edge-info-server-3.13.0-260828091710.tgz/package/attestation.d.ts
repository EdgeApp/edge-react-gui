import { JWK, KeyLike } from 'jose';
export declare const ATTESTATION_TOKEN_ALG = "ES256";
export declare const ATTESTATION_TOKEN_ISSUER = "edge-info-server/attest";
export declare const ATTESTATION_TOKEN_AUDIENCE = "edge-info-server";
export type AttestationAssurance = 'debug' | 'software' | 'hardware' | 'secureElement';
export type AttestationPlatform = 'ios' | 'android';
export declare const ASSURANCE_ORDER: {
    [level in AttestationAssurance]: number;
};
/** True when `level` is at least as strong as `min`. */
export declare const meetsAssurance: (level: AttestationAssurance, min: AttestationAssurance) => boolean;
export interface AttestationTokenClaims {
    assuranceLevel: AttestationAssurance;
    platform: AttestationPlatform;
    appId: string;
    keyId: string;
    verifiedBoot?: boolean;
}
/** Public half of the attestation signing key (e.g. from GET /v1/attest/jwks). */
export type AttestationPublicKey = JWK | KeyLike;
/**
 * Cryptographically verify an attestation JWT and return its claims.
 *
 * Callers fetch the public key once from the info server's JWKS endpoint and
 * pass it here; no request to the attestation API is required per verification.
 */
export declare const verifyAttestationToken: (token: string, publicKey: AttestationPublicKey) => Promise<AttestationTokenClaims>;
