"use strict";Object.defineProperty(exports, "__esModule", {value: true});// Exported for other Edge servers to verify attestation tokens locally.
var _jose = require('jose');

 const ATTESTATION_TOKEN_ALG = 'ES256'; exports.ATTESTATION_TOKEN_ALG = ATTESTATION_TOKEN_ALG
 const ATTESTATION_TOKEN_ISSUER = 'edge-info-server/attest'; exports.ATTESTATION_TOKEN_ISSUER = ATTESTATION_TOKEN_ISSUER
 const ATTESTATION_TOKEN_AUDIENCE = 'edge-info-server'; exports.ATTESTATION_TOKEN_AUDIENCE = ATTESTATION_TOKEN_AUDIENCE

// Every Edge attestation is application-level (it proves the genuine
// co.edgesecure.app identity). A single assurance level captures the trust
// tier (hardware root of trust; dev/debug builds collapse to `debug`):
//   debug         - dev/test build (Apple dev env or Edge debug keystore)
//   software      - release-signed, no secure hardware (e.g. emulator)
//   hardware      - release-signed, TEE-backed key
//   secureElement - release-signed, dedicated secure element (StrongBox / iOS)







// Lowest -> highest ordering, used to compare against a configured minimum.
 const ASSURANCE_ORDER = {
  debug: 0,
  software: 1,
  hardware: 2,
  secureElement: 3
}; exports.ASSURANCE_ORDER = ASSURANCE_ORDER

/** True when `level` is at least as strong as `min`. */
 const meetsAssurance = (
  level,
  min
) => exports.ASSURANCE_ORDER[level] >= exports.ASSURANCE_ORDER[min]; exports.meetsAssurance = meetsAssurance













const isAssurance = (value) =>
  value === 'debug' ||
  value === 'software' ||
  value === 'hardware' ||
  value === 'secureElement'

/** Public half of the attestation signing key (e.g. from GET /v1/attest/jwks). */


const resolvePublicKey = async (
  publicKey
) => {
  if (
    typeof publicKey === 'object' &&
    publicKey != null &&
    'kty' in publicKey
  ) {
    return (await _jose.importJWK.call(void 0, 
      { ...publicKey, alg: exports.ATTESTATION_TOKEN_ALG },
      exports.ATTESTATION_TOKEN_ALG
    )) 
  }
  return publicKey 
}

/**
 * Cryptographically verify an attestation JWT and return its claims.
 *
 * Callers fetch the public key once from the info server's JWKS endpoint and
 * pass it here; no request to the attestation API is required per verification.
 */
 const verifyAttestationToken = async (
  token,
  publicKey
) => {
  const key = await resolvePublicKey(publicKey)
  const { payload } = await _jose.jwtVerify.call(void 0, token, key, {
    issuer: exports.ATTESTATION_TOKEN_ISSUER,
    audience: exports.ATTESTATION_TOKEN_AUDIENCE,
    algorithms: [exports.ATTESTATION_TOKEN_ALG]
  })
  const assuranceLevel = payload.assuranceLevel
  const platform = payload.platform
  const appId = payload.appId
  const keyId = payload.keyId
  if (
    !isAssurance(assuranceLevel) ||
    (platform !== 'ios' && platform !== 'android') ||
    typeof appId !== 'string' ||
    typeof keyId !== 'string'
  ) {
    throw new Error('Malformed attestation token claims')
  }
  return {
    assuranceLevel,
    platform,
    appId,
    keyId,
    // Anything but literal `true` (including absent, for tokens minted before
    // this claim existed) collapses to `false`.
    verifiedBoot: payload.verifiedBoot === true
  }
}; exports.verifyAttestationToken = verifyAttestationToken
