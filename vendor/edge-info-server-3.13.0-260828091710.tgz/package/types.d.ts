import { MangoSelector } from '@edge.app/drupe';
import { Cleaner } from 'cleaners';
export * from './attestation';
export declare const asExposedKey: import("cleaners").ObjectCleaner<{
    pubKeyHash: string;
    exposed: boolean;
}>;
export declare const asDocNotFound: import("cleaners").ObjectCleaner<{
    error: "not_found";
    docId: string;
}>;
export declare const asBulkDbQuery: import("cleaners").ObjectCleaner<{
    docIds: string[];
}>;
export declare const asBulkExposedKeyResponse: import("cleaners").ObjectCleaner<{
    docs: ({
        pubKeyHash: string;
        exposed: boolean;
    } | {
        error: "not_found";
        docId: string;
    })[];
}>;
/** @deprecated use `asInfoCard` */
export declare const asAssetStatus: import("cleaners").ObjectCleaner<{
    appId: string | undefined;
    appVersions: string[] | undefined;
    statusType: "warning" | "info";
    localeStatusTitle: {
        [keys: string]: string;
    };
    localeStatusBody: {
        [keys: string]: string;
    };
    iconUrl: string | undefined;
    statusUrl: string | undefined;
    statusStartIsoDate: string;
    statusEndIsoDate: string;
}>;
/** @deprecated use `asAssetStatus2` */
export declare const asAssetStatusCards: Cleaner<{
    [keys: string]: {
        appId: string | undefined;
        appVersions: string[] | undefined;
        statusType: "warning" | "info";
        localeStatusTitle: {
            [keys: string]: string;
        };
        localeStatusBody: {
            [keys: string]: string;
        };
        iconUrl: string | undefined;
        statusUrl: string | undefined;
        statusStartIsoDate: string;
        statusEndIsoDate: string;
    }[];
}>;
export declare const asGiftCardInfo: import("cleaners").ObjectCleaner<{
    disablePlugins: NestedDisableMap;
}>;
export declare const asMangoSelector: Cleaner<MangoSelector>;
export declare const asAssetSpread: import("cleaners").ObjectCleaner<{
    sourcePluginId: string | undefined;
    sourceTokenId: string | undefined;
    sourceCurrencyCode: string | undefined;
    destPluginId: string | undefined;
    destTokenId: string | undefined;
    destCurrencyCode: string | undefined;
    volatilitySpread: number;
}>;
export declare const asExchangeInfo: import("cleaners").ObjectCleaner<{
    buy: {
        disablePlugins: NestedDisableMap;
    };
    sell: {
        disablePlugins: NestedDisableMap;
    };
    swap: {
        disableAssets: {
            source: /*elided*/ any;
            destination: /*elided*/ any;
        };
        disablePlugins: {
            [keys: string]: boolean;
        } | undefined;
        plugins: {
            thorchain: /*elided*/ any;
            thorchainda: /*elided*/ any;
            swapkit: /*elided*/ any;
            mayaprotocol: /*elided*/ any;
        };
    };
}>;
export declare const asImageGradientBackground: import("cleaners").ObjectCleaner<{
    backgroundGradientColors: string[];
    backgroundGradientStart: {
        x: /*elided*/ any;
        y: /*elided*/ any;
    };
    backgroundGradientEnd: {
        x: /*elided*/ any;
        y: /*elided*/ any;
    };
    imageUri: string;
}>;
export declare const asSurveyOptions: Cleaner<string[]>;
export declare const asInstallSurvey: import("cleaners").ObjectCleaner<{
    surveyOptions: string[];
}>;
export declare const asSurveyOptions2: import("cleaners").ObjectCleaner<{
    ads: {
        [keys: string]: string;
    }[];
    appStore: {
        [keys: string]: string;
    }[];
    article: {
        [keys: string]: string;
    }[];
    inPerson: {
        [keys: string]: string;
    }[];
    referral: {
        [keys: string]: string;
    }[];
    search: {
        [keys: string]: string;
    }[];
    social: {
        [keys: string]: string;
    }[];
}>;
export declare const asInstallSurvey2: import("cleaners").ObjectCleaner<{
    surveyOptions2: {
        ads: /*elided*/ any;
        appStore: /*elided*/ any;
        article: /*elided*/ any;
        inPerson: /*elided*/ any;
        referral: /*elided*/ any;
        search: /*elided*/ any;
        social: /*elided*/ any;
    };
}>;
export declare const asPluginPromotion: import("cleaners").ObjectCleaner<{
    pluginType: "buy" | "sell" | "swap";
    pluginIds: string[] | undefined;
    preferProviders: string[] | undefined;
    providerIds: string[] | undefined;
    promoCode: string | undefined;
}>;
export declare const asInfoCard: import("cleaners").ObjectCleaner<{
    localeMessages: {
        [keys: string]: string;
    };
    ctaButton: {
        localeLabels: {
            [keys: string]: string;
        };
        localeUrls: {
            [keys: string]: string;
        };
    } | undefined;
    background: {
        darkMode: /*elided*/ any;
        lightMode: /*elided*/ any;
    };
    countryCodes: string[] | undefined;
    excludeCountryCodes: string[] | undefined;
    hasLinkedBankMap: {
        [keys: string]: boolean;
    } | undefined;
    exactBuildNum: string | undefined;
    minBuildNum: string | undefined;
    maxBuildNum: string | undefined;
    osTypes: string[] | undefined;
    osVersions: string[] | undefined;
    startIsoDate: string | undefined;
    endIsoDate: string | undefined;
    appVersion: string | undefined;
    noBalance: boolean;
    dismissable: boolean;
    pluginPromotions: {
        pluginType: "buy" | "sell" | "swap";
        pluginIds: string[] | undefined;
        preferProviders: string[] | undefined;
        providerIds: string[] | undefined;
        promoCode: string | undefined;
    }[] | undefined;
    promoId: string | undefined;
}>;
export declare const asPromoCards2: Cleaner<{
    localeMessages: {
        [keys: string]: string;
    };
    ctaButton: {
        localeLabels: {
            [keys: string]: string;
        };
        localeUrls: {
            [keys: string]: string;
        };
    } | undefined;
    background: {
        darkMode: /*elided*/ any;
        lightMode: /*elided*/ any;
    };
    countryCodes: string[] | undefined;
    excludeCountryCodes: string[] | undefined;
    hasLinkedBankMap: {
        [keys: string]: boolean;
    } | undefined;
    exactBuildNum: string | undefined;
    minBuildNum: string | undefined;
    maxBuildNum: string | undefined;
    osTypes: string[] | undefined;
    osVersions: string[] | undefined;
    startIsoDate: string | undefined;
    endIsoDate: string | undefined;
    appVersion: string | undefined;
    noBalance: boolean;
    dismissable: boolean;
    pluginPromotions: {
        pluginType: "buy" | "sell" | "swap";
        pluginIds: string[] | undefined;
        preferProviders: string[] | undefined;
        providerIds: string[] | undefined;
        promoCode: string | undefined;
    }[] | undefined;
    promoId: string | undefined;
}[]>;
export declare const asAssetStatusCards2: Cleaner<Record<string, {
    localeMessages: {
        [keys: string]: string;
    };
    ctaButton: {
        localeLabels: {
            [keys: string]: string;
        };
        localeUrls: {
            [keys: string]: string;
        };
    } | undefined;
    background: {
        darkMode: /*elided*/ any;
        lightMode: /*elided*/ any;
    };
    countryCodes: string[] | undefined;
    excludeCountryCodes: string[] | undefined;
    hasLinkedBankMap: {
        [keys: string]: boolean;
    } | undefined;
    exactBuildNum: string | undefined;
    minBuildNum: string | undefined;
    maxBuildNum: string | undefined;
    osTypes: string[] | undefined;
    osVersions: string[] | undefined;
    startIsoDate: string | undefined;
    endIsoDate: string | undefined;
    appVersion: string | undefined;
    noBalance: boolean;
    dismissable: boolean;
    pluginPromotions: {
        pluginType: "buy" | "sell" | "swap";
        pluginIds: string[] | undefined;
        preferProviders: string[] | undefined;
        providerIds: string[] | undefined;
        promoCode: string | undefined;
    }[] | undefined;
    promoId: string | undefined;
}[]>>;
export declare const asStakeStatusCards: Cleaner<Record<string, {
    localeMessages: {
        [keys: string]: string;
    };
    ctaButton: {
        localeLabels: {
            [keys: string]: string;
        };
        localeUrls: {
            [keys: string]: string;
        };
    } | undefined;
    background: {
        darkMode: /*elided*/ any;
        lightMode: /*elided*/ any;
    };
    countryCodes: string[] | undefined;
    excludeCountryCodes: string[] | undefined;
    hasLinkedBankMap: {
        [keys: string]: boolean;
    } | undefined;
    exactBuildNum: string | undefined;
    minBuildNum: string | undefined;
    maxBuildNum: string | undefined;
    osTypes: string[] | undefined;
    osVersions: string[] | undefined;
    startIsoDate: string | undefined;
    endIsoDate: string | undefined;
    appVersion: string | undefined;
    noBalance: boolean;
    dismissable: boolean;
    pluginPromotions: {
        pluginType: "buy" | "sell" | "swap";
        pluginIds: string[] | undefined;
        preferProviders: string[] | undefined;
        providerIds: string[] | undefined;
        promoCode: string | undefined;
    }[] | undefined;
    promoId: string | undefined;
}[]>>;
export declare const asAssetInfoCards: Cleaner<Record<string, {
    localeMessages: {
        [keys: string]: string;
    };
    ctaButton: {
        localeLabels: {
            [keys: string]: string;
        };
        localeUrls: {
            [keys: string]: string;
        };
    } | undefined;
    background: {
        darkMode: /*elided*/ any;
        lightMode: /*elided*/ any;
    };
    countryCodes: string[] | undefined;
    excludeCountryCodes: string[] | undefined;
    hasLinkedBankMap: {
        [keys: string]: boolean;
    } | undefined;
    exactBuildNum: string | undefined;
    minBuildNum: string | undefined;
    maxBuildNum: string | undefined;
    osTypes: string[] | undefined;
    osVersions: string[] | undefined;
    startIsoDate: string | undefined;
    endIsoDate: string | undefined;
    appVersion: string | undefined;
    noBalance: boolean;
    dismissable: boolean;
    pluginPromotions: {
        pluginType: "buy" | "sell" | "swap";
        pluginIds: string[] | undefined;
        preferProviders: string[] | undefined;
        providerIds: string[] | undefined;
        promoCode: string | undefined;
    }[] | undefined;
    promoId: string | undefined;
}[]>>;
export declare const asAppIdInfo: import("cleaners").ObjectCleaner<{
    appName: string;
    imageUrl: string | undefined;
    hidePoweredBy: boolean;
    lightImageUrl: string | undefined;
    darkImageUrl: string | undefined;
}>;
export declare const asApyValues: import("cleaners").ObjectCleaner<{
    policies: {
        [keys: string]: number;
    };
}>;
export declare const asAssetOverrides: import("cleaners").ObjectCleaner<{
    disable: {
        [keys: string]: boolean;
    };
}>;
export declare const asBlockBook: Cleaner<{
    [keys: string]: string[] | null;
}>;
/**
 * List of blog posts to show on home screen
 * @deprecated - Use `asContentPost` instead
 */
export declare const asBlogPost: import("cleaners").ObjectCleaner<{
    localeTitle: {
        [keys: string]: string;
    };
    localeBody: {
        [keys: string]: string;
    };
    localeBlogUrl: {
        [keys: string]: string;
    };
    lightImageUrl: string;
    darkImageUrl: string;
}>;
/** @deprecated - Use `asContentPost` instead */
export declare const asBlogPosts: Cleaner<{
    localeTitle: {
        [keys: string]: string;
    };
    localeBody: {
        [keys: string]: string;
    };
    localeBlogUrl: {
        [keys: string]: string;
    };
    lightImageUrl: string;
    darkImageUrl: string;
}[]>;
/**
 * Basic content post (videos, blogs, etc) shape.
 *
 * NOTE: `localeBlogUrl` is for *any* CTA URL associated with this content, not
 * just for blogs.
 */
export declare const asContentPost: import("cleaners").ObjectCleaner<{
    countryCodes: string[];
    excludeCountryCodes: string[];
    localeTitle: {
        [keys: string]: string;
    };
    localeBody: {
        [keys: string]: string;
    };
    localeBlogUrl: {
        [keys: string]: string;
    };
    lightImageUrl: string;
    darkImageUrl: string;
}>;
export declare const asContentPosts: Cleaner<{
    countryCodes: string[];
    excludeCountryCodes: string[];
    localeTitle: {
        [keys: string]: string;
    };
    localeBody: {
        [keys: string]: string;
    };
    localeBlogUrl: {
        [keys: string]: string;
    };
    lightImageUrl: string;
    darkImageUrl: string;
}[]>;
/**
 * This is the internal data for each of the core plugins.
 */
export declare const asCorePluginsInternal: Cleaner<CorePluginsInternal>;
export interface CorePluginsInternal {
    [pluginId: string]: unknown;
}
/** Backwards compatiblity prior to genericized ContentPosts type. */
export declare const asBlogPostGeo: import("cleaners").ObjectCleaner<{
    countryCodes: string[];
    excludeCountryCodes: string[];
    localeTitle: {
        [keys: string]: string;
    };
    localeBody: {
        [keys: string]: string;
    };
    localeBlogUrl: {
        [keys: string]: string;
    };
    lightImageUrl: string;
    darkImageUrl: string;
}>;
export declare const asBlogPostsGeo: Cleaner<{
    countryCodes: string[];
    excludeCountryCodes: string[];
    localeTitle: {
        [keys: string]: string;
    };
    localeBody: {
        [keys: string]: string;
    };
    localeBlogUrl: {
        [keys: string]: string;
    };
    lightImageUrl: string;
    darkImageUrl: string;
}[]>;
/** Latest app version info */
export declare const asUpdateVersionMessage: import("cleaners").ObjectCleaner<{
    updateVersion: string;
    localeMessage: {
        [keys: string]: string;
    };
}>;
export declare const asUpdateInfo: Cleaner<{
    [keys: string]: {
        updateVersion: string;
        localeMessage: {
            [keys: string]: string;
        };
    };
}>;
/**
 * The plugin list scene stores its data in JSON files,
 * which have an array of these rows unknown with strings for comments.
 */
declare const asGuiPluginJsonRow: import("cleaners").ObjectCleaner<{
    id: string;
    pluginId: string | undefined;
    deepPath: string | undefined;
    deepQuery: {
        [keys: string]: string | null;
    } | undefined;
    paymentType: unknown;
    title: string | undefined;
    customTitleKey: string | undefined;
    description: string | undefined;
    partnerIconPath: string | undefined;
    paymentTypeLogoKey: string | undefined;
    paymentTypes: string[] | undefined;
    cryptoCodes: string[] | undefined;
    forCountries: string[] | undefined;
    forStateProvinces: {
        [keys: string]: string[];
    } | undefined;
    notStateProvinces: {
        [keys: string]: string[];
    } | undefined;
    forPlatform: string | undefined;
    sortIndex: number | undefined;
}>;
type GuiPluginJsonRow = ReturnType<typeof asGuiPluginJsonRow>;
export declare const asGuiPluginJson: Cleaner<Array<string | GuiPluginJsonRow>>;
export declare const asBuySellPlugins: import("cleaners").ObjectCleaner<{
    buy: (string | {
        id: string;
        pluginId: string | undefined;
        deepPath: string | undefined;
        deepQuery: {
            [keys: string]: string | null;
        } | undefined;
        paymentType: unknown;
        title: string | undefined;
        customTitleKey: string | undefined;
        description: string | undefined;
        partnerIconPath: string | undefined;
        paymentTypeLogoKey: string | undefined;
        paymentTypes: string[] | undefined;
        cryptoCodes: string[] | undefined;
        forCountries: string[] | undefined;
        forStateProvinces: {
            [keys: string]: string[];
        } | undefined;
        notStateProvinces: {
            [keys: string]: string[];
        } | undefined;
        forPlatform: string | undefined;
        sortIndex: number | undefined;
    })[] | undefined;
    sell: (string | {
        id: string;
        pluginId: string | undefined;
        deepPath: string | undefined;
        deepQuery: {
            [keys: string]: string | null;
        } | undefined;
        paymentType: unknown;
        title: string | undefined;
        customTitleKey: string | undefined;
        description: string | undefined;
        partnerIconPath: string | undefined;
        paymentTypeLogoKey: string | undefined;
        paymentTypes: string[] | undefined;
        cryptoCodes: string[] | undefined;
        forCountries: string[] | undefined;
        forStateProvinces: {
            [keys: string]: string[];
        } | undefined;
        notStateProvinces: {
            [keys: string]: string[];
        } | undefined;
        forPlatform: string | undefined;
        sortIndex: number | undefined;
    })[] | undefined;
}>;
export declare const asEosPrices: Cleaner<{
    [keys: string]: string;
}>;
/**
 * Common network fee cleaner
 */
export type FeeRates = ReturnType<typeof asFeeRates>;
export declare const asFeeRates: import("cleaners").ObjectCleaner<{
    lowFee: string;
    standardFeeLow: string;
    standardFeeHigh: string;
    standardFeeLowAmount: string;
    standardFeeHighAmount: string;
    highFee: string;
}>;
/**
 * UTXO specific fees
 */
export type UtxoFeeRates = ReturnType<typeof asUtxoFeeRates>;
export declare const asUtxoFeeRates: import("cleaners").ObjectCleaner<{
    lowFeeFudgeFactor: string | undefined;
    standardFeeLowFudgeFactor: string | undefined;
    standardFeeHighFudgeFactor: string | undefined;
    highFeeFudgeFactor: string | undefined;
    lowFee: string;
    standardFeeLow: string;
    standardFeeHigh: string;
    standardFeeLowAmount: string;
    standardFeeHighAmount: string;
    highFee: string;
}>;
/**
 * Gas-based Network Fees
 */
export type EvmBaseFeeMultiplier = ReturnType<typeof asEvmBaseFeeMultiplier>;
export declare const asEvmBaseFeeMultiplier: import("cleaners").ObjectCleaner<{
    lowFee: string;
    standardFeeLow: string;
    standardFeeHigh: string;
    highFee: string;
}>;
export type EvmGasLimit = ReturnType<typeof asEvmGasLimit>;
export declare const asEvmGasLimit: import("cleaners").ObjectCleaner<{
    minGasLimit: string | undefined;
    regularTransaction: string;
    tokenTransaction: string;
}>;
export type EvmGasPrice = ReturnType<typeof asEvmGasPrice>;
export declare const asEvmGasPrice: import("cleaners").ObjectCleaner<{
    minGasPrice: string | undefined;
    lowFee: string;
    standardFeeLow: string;
    standardFeeHigh: string;
    standardFeeLowAmount: string;
    standardFeeHighAmount: string;
    highFee: string;
}>;
export type GasFeeSettings = ReturnType<typeof asGasFeeSettings>;
export declare const asGasFeeSettings: import("cleaners").ObjectCleaner<{
    baseFeeMultiplier: {
        lowFee: string;
        standardFeeLow: string;
        standardFeeHigh: string;
        highFee: string;
    } | undefined;
    gasLimit: {
        minGasLimit: string | undefined;
        regularTransaction: string;
        tokenTransaction: string;
    } | undefined;
    gasPrice: {
        minGasPrice: string | undefined;
        lowFee: string;
        standardFeeLow: string;
        standardFeeHigh: string;
        standardFeeLowAmount: string;
        standardFeeHighAmount: string;
        highFee: string;
    } | undefined;
    minPriorityFee: string | undefined;
}>;
export declare const asEvmBasedFees: Cleaner<{
    [keys: string]: {
        baseFeeMultiplier: {
            lowFee: string;
            standardFeeLow: string;
            standardFeeHigh: string;
            highFee: string;
        } | undefined;
        gasLimit: {
            minGasLimit: string | undefined;
            regularTransaction: string;
            tokenTransaction: string;
        } | undefined;
        gasPrice: {
            minGasPrice: string | undefined;
            lowFee: string;
            standardFeeLow: string;
            standardFeeHigh: string;
            standardFeeLowAmount: string;
            standardFeeHighAmount: string;
            highFee: string;
        } | undefined;
        minPriorityFee: string | undefined;
    };
}>;
export type EvmBasedFees = ReturnType<typeof asEvmBasedFees>;
/**
 * Union of all network fee settings
 */
export declare const asNetworkFee: Cleaner<{
    lowFeeFudgeFactor: string | undefined;
    standardFeeLowFudgeFactor: string | undefined;
    standardFeeHighFudgeFactor: string | undefined;
    highFeeFudgeFactor: string | undefined;
    lowFee: string;
    standardFeeLow: string;
    standardFeeHigh: string;
    standardFeeLowAmount: string;
    standardFeeHighAmount: string;
    highFee: string;
} | {
    [keys: string]: {
        baseFeeMultiplier: {
            lowFee: string;
            standardFeeLow: string;
            standardFeeHigh: string;
            highFee: string;
        } | undefined;
        gasLimit: {
            minGasLimit: string | undefined;
            regularTransaction: string;
            tokenTransaction: string;
        } | undefined;
        gasPrice: {
            minGasPrice: string | undefined;
            lowFee: string;
            standardFeeLow: string;
            standardFeeHigh: string;
            standardFeeLowAmount: string;
            standardFeeHighAmount: string;
            highFee: string;
        } | undefined;
        minPriorityFee: string | undefined;
    };
}>;
export declare const asNetworkFees: Cleaner<{
    [keys: string]: {
        lowFeeFudgeFactor: string | undefined;
        standardFeeLowFudgeFactor: string | undefined;
        standardFeeHighFudgeFactor: string | undefined;
        highFeeFudgeFactor: string | undefined;
        lowFee: string;
        standardFeeLow: string;
        standardFeeHigh: string;
        standardFeeLowAmount: string;
        standardFeeHighAmount: string;
        highFee: string;
    } | {
        [keys: string]: {
            baseFeeMultiplier: {
                lowFee: string;
                standardFeeLow: string;
                standardFeeHigh: string;
                highFee: string;
            } | undefined;
            gasLimit: {
                minGasLimit: string | undefined;
                regularTransaction: string;
                tokenTransaction: string;
            } | undefined;
            gasPrice: {
                minGasPrice: string | undefined;
                lowFee: string;
                standardFeeLow: string;
                standardFeeHigh: string;
                standardFeeLowAmount: string;
                standardFeeHighAmount: string;
                highFee: string;
            } | undefined;
            minPriorityFee: string | undefined;
        };
    };
}>;
export type NetworkFees = ReturnType<typeof asNetworkFees>;
export declare const asFiatPluginPriority: Cleaner<{
    [keys: string]: {
        [keys: string]: number;
    };
}>;
export declare const asFioAssets: Cleaner<Record<string, {
    chainCode: string;
    tokenCodes: {
        [keys: string]: string;
    };
}>>;
export declare const asInfoRollup: import("cleaners").ObjectCleaner<{
    appIdInfo: {
        [keys: string]: {
            appName: string;
            imageUrl: string | undefined;
            hidePoweredBy: boolean;
            lightImageUrl: string | undefined;
            darkImageUrl: string | undefined;
        };
    };
    apyValues: {
        policies: /*elided*/ any;
    };
    assetOverrides: {
        disable: {
            [keys: string]: boolean;
        };
    } | undefined;
    assetInfoCards: Record<string, {
        localeMessages: {
            [keys: string]: string;
        };
        ctaButton: {
            localeLabels: {
                [keys: string]: string;
            };
            localeUrls: {
                [keys: string]: string;
            };
        } | undefined;
        background: {
            darkMode: /*elided*/ any;
            lightMode: /*elided*/ any;
        };
        countryCodes: string[] | undefined;
        excludeCountryCodes: string[] | undefined;
        hasLinkedBankMap: {
            [keys: string]: boolean;
        } | undefined;
        exactBuildNum: string | undefined;
        minBuildNum: string | undefined;
        maxBuildNum: string | undefined;
        osTypes: string[] | undefined;
        osVersions: string[] | undefined;
        startIsoDate: string | undefined;
        endIsoDate: string | undefined;
        appVersion: string | undefined;
        noBalance: boolean;
        dismissable: boolean;
        pluginPromotions: {
            pluginType: "buy" | "sell" | "swap";
            pluginIds: string[] | undefined;
            preferProviders: string[] | undefined;
            providerIds: string[] | undefined;
            promoCode: string | undefined;
        }[] | undefined;
        promoId: string | undefined;
    }[]> | undefined;
    assetStatusCards: {
        [keys: string]: {
            appId: string | undefined;
            appVersions: string[] | undefined;
            statusType: "warning" | "info";
            localeStatusTitle: {
                [keys: string]: string;
            };
            localeStatusBody: {
                [keys: string]: string;
            };
            iconUrl: string | undefined;
            statusUrl: string | undefined;
            statusStartIsoDate: string;
            statusEndIsoDate: string;
        }[];
    } | undefined;
    assetStatusCards2: Record<string, {
        localeMessages: {
            [keys: string]: string;
        };
        ctaButton: {
            localeLabels: {
                [keys: string]: string;
            };
            localeUrls: {
                [keys: string]: string;
            };
        } | undefined;
        background: {
            darkMode: /*elided*/ any;
            lightMode: /*elided*/ any;
        };
        countryCodes: string[] | undefined;
        excludeCountryCodes: string[] | undefined;
        hasLinkedBankMap: {
            [keys: string]: boolean;
        } | undefined;
        exactBuildNum: string | undefined;
        minBuildNum: string | undefined;
        maxBuildNum: string | undefined;
        osTypes: string[] | undefined;
        osVersions: string[] | undefined;
        startIsoDate: string | undefined;
        endIsoDate: string | undefined;
        appVersion: string | undefined;
        noBalance: boolean;
        dismissable: boolean;
        pluginPromotions: {
            pluginType: "buy" | "sell" | "swap";
            pluginIds: string[] | undefined;
            preferProviders: string[] | undefined;
            providerIds: string[] | undefined;
            promoCode: string | undefined;
        }[] | undefined;
        promoId: string | undefined;
    }[]> | undefined;
    blockBook: {
        [keys: string]: string[] | null;
    };
    blogPosts: {
        localeTitle: {
            [keys: string]: string;
        };
        localeBody: {
            [keys: string]: string;
        };
        localeBlogUrl: {
            [keys: string]: string;
        };
        lightImageUrl: string;
        darkImageUrl: string;
    }[] | undefined;
    blogPostsGeo: {
        countryCodes: string[];
        excludeCountryCodes: string[];
        localeTitle: {
            [keys: string]: string;
        };
        localeBody: {
            [keys: string]: string;
        };
        localeBlogUrl: {
            [keys: string]: string;
        };
        lightImageUrl: string;
        darkImageUrl: string;
    }[] | undefined;
    buySellPlugins: {
        buy: (string | {
            id: string;
            pluginId: string | undefined;
            deepPath: string | undefined;
            deepQuery: {
                [keys: string]: string | null;
            } | undefined;
            paymentType: unknown;
            title: string | undefined;
            customTitleKey: string | undefined;
            description: string | undefined;
            partnerIconPath: string | undefined;
            paymentTypeLogoKey: string | undefined;
            paymentTypes: string[] | undefined;
            cryptoCodes: string[] | undefined;
            forCountries: string[] | undefined;
            forStateProvinces: {
                [keys: string]: string[];
            } | undefined;
            notStateProvinces: {
                [keys: string]: string[];
            } | undefined;
            forPlatform: string | undefined;
            sortIndex: number | undefined;
        })[] | undefined;
        sell: (string | {
            id: string;
            pluginId: string | undefined;
            deepPath: string | undefined;
            deepQuery: {
                [keys: string]: string | null;
            } | undefined;
            paymentType: unknown;
            title: string | undefined;
            customTitleKey: string | undefined;
            description: string | undefined;
            partnerIconPath: string | undefined;
            paymentTypeLogoKey: string | undefined;
            paymentTypes: string[] | undefined;
            cryptoCodes: string[] | undefined;
            forCountries: string[] | undefined;
            forStateProvinces: {
                [keys: string]: string[];
            } | undefined;
            notStateProvinces: {
                [keys: string]: string[];
            } | undefined;
            forPlatform: string | undefined;
            sortIndex: number | undefined;
        })[] | undefined;
    } | undefined;
    buySellPluginsPatch: {
        buy: (string | {
            id: string;
            pluginId: string | undefined;
            deepPath: string | undefined;
            deepQuery: {
                [keys: string]: string | null;
            } | undefined;
            paymentType: unknown;
            title: string | undefined;
            customTitleKey: string | undefined;
            description: string | undefined;
            partnerIconPath: string | undefined;
            paymentTypeLogoKey: string | undefined;
            paymentTypes: string[] | undefined;
            cryptoCodes: string[] | undefined;
            forCountries: string[] | undefined;
            forStateProvinces: {
                [keys: string]: string[];
            } | undefined;
            notStateProvinces: {
                [keys: string]: string[];
            } | undefined;
            forPlatform: string | undefined;
            sortIndex: number | undefined;
        })[] | undefined;
        sell: (string | {
            id: string;
            pluginId: string | undefined;
            deepPath: string | undefined;
            deepQuery: {
                [keys: string]: string | null;
            } | undefined;
            paymentType: unknown;
            title: string | undefined;
            customTitleKey: string | undefined;
            description: string | undefined;
            partnerIconPath: string | undefined;
            paymentTypeLogoKey: string | undefined;
            paymentTypes: string[] | undefined;
            cryptoCodes: string[] | undefined;
            forCountries: string[] | undefined;
            forStateProvinces: {
                [keys: string]: string[];
            } | undefined;
            notStateProvinces: {
                [keys: string]: string[];
            } | undefined;
            forPlatform: string | undefined;
            sortIndex: number | undefined;
        })[] | undefined;
    } | undefined;
    exchangeInfo: {
        buy: {
            disablePlugins: NestedDisableMap;
        };
        sell: {
            disablePlugins: NestedDisableMap;
        };
        swap: {
            disableAssets: {
                source: /*elided*/ any;
                destination: /*elided*/ any;
            };
            disablePlugins: {
                [keys: string]: boolean;
            } | undefined;
            plugins: {
                thorchain: /*elided*/ any;
                thorchainda: /*elided*/ any;
                swapkit: /*elided*/ any;
                mayaprotocol: /*elided*/ any;
            };
        };
    } | undefined;
    fiatPluginPriority: {
        [keys: string]: {
            [keys: string]: number;
        };
    } | undefined;
    fioAssets: Record<string, {
        chainCode: string;
        tokenCodes: {
            [keys: string]: string;
        };
    }> | undefined;
    installSurvey: {
        surveyOptions: string[];
    } | undefined;
    installSurvey2: {
        surveyOptions2: {
            ads: /*elided*/ any;
            appStore: /*elided*/ any;
            article: /*elided*/ any;
            inPerson: /*elided*/ any;
            referral: /*elided*/ any;
            search: /*elided*/ any;
            social: /*elided*/ any;
        };
    } | undefined;
    networkFees: {
        [keys: string]: {
            lowFeeFudgeFactor: string | undefined;
            standardFeeLowFudgeFactor: string | undefined;
            standardFeeHighFudgeFactor: string | undefined;
            highFeeFudgeFactor: string | undefined;
            lowFee: string;
            standardFeeLow: string;
            standardFeeHigh: string;
            standardFeeLowAmount: string;
            standardFeeHighAmount: string;
            highFee: string;
        } | {
            [keys: string]: {
                baseFeeMultiplier: {
                    lowFee: string;
                    standardFeeLow: string;
                    standardFeeHigh: string;
                    highFee: string;
                } | undefined;
                gasLimit: {
                    minGasLimit: string | undefined;
                    regularTransaction: string;
                    tokenTransaction: string;
                } | undefined;
                gasPrice: {
                    minGasPrice: string | undefined;
                    lowFee: string;
                    standardFeeLow: string;
                    standardFeeHigh: string;
                    standardFeeLowAmount: string;
                    standardFeeHighAmount: string;
                    highFee: string;
                } | undefined;
                minPriorityFee: string | undefined;
            };
        };
    };
    promoCards2: {
        localeMessages: {
            [keys: string]: string;
        };
        ctaButton: {
            localeLabels: {
                [keys: string]: string;
            };
            localeUrls: {
                [keys: string]: string;
            };
        } | undefined;
        background: {
            darkMode: /*elided*/ any;
            lightMode: /*elided*/ any;
        };
        countryCodes: string[] | undefined;
        excludeCountryCodes: string[] | undefined;
        hasLinkedBankMap: {
            [keys: string]: boolean;
        } | undefined;
        exactBuildNum: string | undefined;
        minBuildNum: string | undefined;
        maxBuildNum: string | undefined;
        osTypes: string[] | undefined;
        osVersions: string[] | undefined;
        startIsoDate: string | undefined;
        endIsoDate: string | undefined;
        appVersion: string | undefined;
        noBalance: boolean;
        dismissable: boolean;
        pluginPromotions: {
            pluginType: "buy" | "sell" | "swap";
            pluginIds: string[] | undefined;
            preferProviders: string[] | undefined;
            providerIds: string[] | undefined;
            promoCode: string | undefined;
        }[] | undefined;
        promoId: string | undefined;
    }[] | undefined;
    rampQuoteFilter: {
        [keys: string]: MangoSelector;
    } | undefined;
    giftCardInfo: {
        disablePlugins: NestedDisableMap;
    } | undefined;
    stakeStatusCards: Record<string, {
        localeMessages: {
            [keys: string]: string;
        };
        ctaButton: {
            localeLabels: {
                [keys: string]: string;
            };
            localeUrls: {
                [keys: string]: string;
            };
        } | undefined;
        background: {
            darkMode: /*elided*/ any;
            lightMode: /*elided*/ any;
        };
        countryCodes: string[] | undefined;
        excludeCountryCodes: string[] | undefined;
        hasLinkedBankMap: {
            [keys: string]: boolean;
        } | undefined;
        exactBuildNum: string | undefined;
        minBuildNum: string | undefined;
        maxBuildNum: string | undefined;
        osTypes: string[] | undefined;
        osVersions: string[] | undefined;
        startIsoDate: string | undefined;
        endIsoDate: string | undefined;
        appVersion: string | undefined;
        noBalance: boolean;
        dismissable: boolean;
        pluginPromotions: {
            pluginType: "buy" | "sell" | "swap";
            pluginIds: string[] | undefined;
            preferProviders: string[] | undefined;
            providerIds: string[] | undefined;
            promoCode: string | undefined;
        }[] | undefined;
        promoId: string | undefined;
    }[]> | undefined;
    updateInfo: {
        [keys: string]: {
            updateVersion: string;
            localeMessage: {
                [keys: string]: string;
            };
        };
    } | undefined;
    videoPosts: {
        countryCodes: string[];
        excludeCountryCodes: string[];
        localeTitle: {
            [keys: string]: string;
        };
        localeBody: {
            [keys: string]: string;
        };
        localeBlogUrl: {
            [keys: string]: string;
        };
        lightImageUrl: string;
        darkImageUrl: string;
    }[] | undefined;
    appKeys: {
        [keys: string]: unknown;
    } | undefined;
    assuranceLevel: string | undefined;
}>;
export type ImageGradientBackground = ReturnType<typeof asImageGradientBackground>;
export type AssetStatus = ReturnType<typeof asAssetStatus>;
export type BlogPost = ReturnType<typeof asBlogPost>;
export type BlogPostGeo = ReturnType<typeof asBlogPostGeo>;
export type BulkDbQuery = ReturnType<typeof asBulkDbQuery>;
export type BulkExposedKeyResponse = ReturnType<typeof asBulkExposedKeyResponse>;
export type ContentPost = ReturnType<typeof asContentPost>;
export type DocNotFound = ReturnType<typeof asDocNotFound>;
export type ExchangeInfo = ReturnType<typeof asExchangeInfo>;
export type GiftCardInfo = ReturnType<typeof asGiftCardInfo>;
export type ExposedKey = ReturnType<typeof asExposedKey>;
export type FioAssets = ReturnType<typeof asFioAssets>;
export type InfoCard = ReturnType<typeof asInfoCard>;
export type InstallSurvey2 = ReturnType<typeof asInstallSurvey2>;
export type PluginPromotion = ReturnType<typeof asPluginPromotion>;
export interface NestedDisableMap {
    [pluginId: string]: boolean | NestedDisableMap;
}
export type InfoRollup = ReturnType<typeof asInfoRollup>;
