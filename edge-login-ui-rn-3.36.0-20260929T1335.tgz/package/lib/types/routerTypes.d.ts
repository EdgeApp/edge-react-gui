import { ChangePasswordParams, NewAccountPasswordParams, ResecurePasswordParams, UpgradePasswordParams } from '../components/scenes/ChangePasswordScene';
import { ChangePinParams, NewAccountPinParams, ResecurePinParams } from '../components/scenes/ChangePinScene';
import { ChangeRecoveryParams } from '../components/scenes/existingAccout/ChangeRecoveryScene';
import { ChangeUsernameParams } from '../components/scenes/existingAccout/ChangeUsernameScene';
import { OtpRepairParams } from '../components/scenes/existingAccout/OtpRepairScene';
import { SecurityAlertParams } from '../components/scenes/existingAccout/SecurityAlertsScene';
import { LoginParams } from '../components/scenes/LoginScene';
import { NewAccountReviewParams, UpgradeAccountReviewParams } from '../components/scenes/newAccount/NewAccountReviewScene';
import { NewAccountTosParams, UpgradeTosParams } from '../components/scenes/newAccount/NewAccountTosScene';
import { NewAccountUsernameParams, UpgradeUsernameParams } from '../components/scenes/newAccount/NewAccountUsernameScene';
import { NewAccountWaitParams } from '../components/scenes/newAccount/NewAccountWaitScene';
import { OtpErrorParams } from '../components/scenes/OtpErrorScene';
import { RecoveryLoginParams } from '../components/scenes/RecoveryLoginScene';
/**
 * Defines the acceptable route parameters for each scene key.
 */
export interface LoginParamList {
    changeUsername: ChangeUsernameParams;
    changePassword: ChangePasswordParams;
    changePin: ChangePinParams;
    changeRecovery: ChangeRecoveryParams;
    newAccountWelcome: {};
    newAccountUsername: NewAccountUsernameParams;
    newAccountPassword: NewAccountPasswordParams;
    newAccountPin: NewAccountPinParams;
    newAccountTos: NewAccountTosParams;
    newAccountWait: NewAccountWaitParams;
    newAccountReview: NewAccountReviewParams;
    upgradeUsername: UpgradeUsernameParams;
    upgradePassword: UpgradePasswordParams;
    upgradeTos: UpgradeTosParams;
    upgradeAccountReview: UpgradeAccountReviewParams;
    landing: {};
    loading: {};
    login: LoginParams;
    otpError: OtpErrorParams;
    otpRepair: OtpRepairParams;
    recoveryLogin: RecoveryLoginParams;
    resecurePassword: ResecurePasswordParams;
    resecurePin: ResecurePinParams;
    securityAlert: SecurityAlertParams;
}
/**
 * The `route` prop passed to each scene.
 */
export interface RouteProp<Name extends keyof LoginParamList> {
    name: Name;
    params: LoginParamList[Name];
}
/**
 * The props passed to each scene.
 */
export interface SceneProps<Name extends keyof LoginParamList> {
    route: RouteProp<Name>;
}
