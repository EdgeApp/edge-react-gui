import * as React from 'react';
interface Props {
    title: string;
    icon?: React.ReactNode;
    minimumFontScale?: number;
    subTitle?: string;
    testID?: string;
    onPress: () => Promise<void> | void;
}
/**
 * A whole-card tappable row that leads with the title in primary text and puts
 * a smaller blue explanation underneath, the way the GUI's Help modal presents
 * its options.
 *
 * Trimmed port of edge-react-gui's `SelectableRow`. login-ui only needs the
 * tappable variant, so the GUI component's disabled (dimmed, non-interactive)
 * state is intentionally omitted; the `testID` prop is the one addition, since
 * this SDK's flows target rows by handle. Keep the shared props a strict subset
 * of the GUI component so a later full sync stays compatible.
 *
 * The subtitle reads `theme.selectableRowSubtitle` rather than the GUI's
 * `theme.secondaryText`: login-ui's `secondaryText` is a muted blue-grey that
 * nine other call sites depend on, so the accent blue lives in its own key.
 */
export declare const SelectableRow: React.FC<Props>;
export {};
