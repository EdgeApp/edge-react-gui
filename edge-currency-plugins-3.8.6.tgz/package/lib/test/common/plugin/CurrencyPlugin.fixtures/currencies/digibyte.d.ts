import { FixtureType } from '../common';
export declare const digibyte: FixtureType;
