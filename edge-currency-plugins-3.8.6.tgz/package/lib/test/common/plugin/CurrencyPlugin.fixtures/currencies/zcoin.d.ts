import { FixtureType } from '../common';
export declare const zcoin: FixtureType;
