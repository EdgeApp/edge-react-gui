import { FixtureType } from '../common';
export declare const groestlcoin: FixtureType;
