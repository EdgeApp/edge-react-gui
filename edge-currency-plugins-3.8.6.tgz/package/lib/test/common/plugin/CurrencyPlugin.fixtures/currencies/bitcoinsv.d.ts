import { FixtureType } from '../common';
export declare const bitcoinsv: FixtureType;
