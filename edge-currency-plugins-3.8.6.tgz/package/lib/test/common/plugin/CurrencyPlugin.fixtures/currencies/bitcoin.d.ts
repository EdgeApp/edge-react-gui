import { FixtureType } from '../common';
export declare const bitcoin: FixtureType;
