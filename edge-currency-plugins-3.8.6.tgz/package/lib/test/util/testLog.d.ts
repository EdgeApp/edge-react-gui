import { EdgeLog } from 'edge-core-js/types';
export declare const noOp: (..._args: any[]) => void;
export declare const testLog: EdgeLog;
