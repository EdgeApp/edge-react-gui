import { MemletConfig } from 'memlet';
export declare const pluginUri: string;
export declare const debugUri = "http://localhost:8084/edge-currency-plugins.js";
export interface EdgeCurrencyPluginIoOptions {
    readonly memletConfig?: MemletConfig;
}
export interface EdgeCurrencyPluginNativeIo {
    readonly memletConfig?: MemletConfig;
}
export declare function makePluginIo(options?: EdgeCurrencyPluginIoOptions): EdgeCurrencyPluginNativeIo;
