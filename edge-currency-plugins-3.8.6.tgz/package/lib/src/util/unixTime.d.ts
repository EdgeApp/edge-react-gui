export declare const unixTime: (ts?: number) => number;
