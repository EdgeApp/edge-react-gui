export declare const filterUndefined: <T>(values: (T | undefined)[]) => T[];
export declare const removeUndefined: <T extends Record<string, any>>(obj: T) => Partial<T>;
