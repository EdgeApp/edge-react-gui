import { Cleaner } from 'cleaners';
/**
 * A string of hex-encoded binary data.
 */
export declare const asBase16: Cleaner<Uint8Array>;
export declare function asIntegerString(raw: unknown): string;
