export declare function getUriKeyParams(uri: string): string[];
export declare function replaceKeyParams<T extends string>(uri: string, options: {
    [P in T]?: string;
}): string;
