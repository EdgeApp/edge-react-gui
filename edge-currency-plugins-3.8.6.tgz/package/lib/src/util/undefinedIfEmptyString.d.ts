export declare const undefinedIfEmptyString: (str?: string | undefined) => string | undefined;
