/**
 * Gets an element out of an array but includes protection if the index
 * overflows the length of the array.
 **/
export declare const indexAtProtected: <T extends any[] | undefined>(array: T, index: number) => T extends (infer U)[] ? U : undefined;
