import { EdgeCurrencyInfo, EdgeMemoOption } from 'edge-core-js/types';
export declare const utxoCustomFeeTemplate: EdgeCurrencyInfo['customFeeTemplate'];
export declare const utxoMemoOptions: EdgeMemoOption[];
export declare const legacyMemoInfo: Partial<EdgeCurrencyInfo>;
