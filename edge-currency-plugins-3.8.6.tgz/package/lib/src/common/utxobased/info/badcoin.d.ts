import { CoinInfo, PluginInfo } from '../../plugin/types';
export declare const coinInfo: CoinInfo;
export declare const info: PluginInfo;
