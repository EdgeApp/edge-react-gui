import { ScriptTemplates } from './types';
export declare const scriptTemplates: ScriptTemplates;
