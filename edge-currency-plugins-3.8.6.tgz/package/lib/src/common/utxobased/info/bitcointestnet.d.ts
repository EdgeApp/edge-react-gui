import { EdgeCurrencyInfo } from 'edge-core-js/types';
import { CoinInfo, EngineInfo, PluginInfo } from '../../plugin/types';
export declare const currencyInfo: EdgeCurrencyInfo;
export declare const engineInfo: EngineInfo;
export declare const coinInfo: CoinInfo;
export declare const info: PluginInfo;
