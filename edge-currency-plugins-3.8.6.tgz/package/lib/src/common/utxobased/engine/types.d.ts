import { EdgeSpendInfo } from 'edge-core-js/types';
import { Input, Output } from '../keymanager/utxopicker/types';
export interface UtxoInitOptions {
    nowNodesApiKey?: string;
}
export declare const asUtxoInitOptions: import("cleaners").ObjectCleaner<UtxoInitOptions>;
export declare const asUtxoUserSettings: import("cleaners").ObjectCleaner<{
    blockbookServers: string[];
    enableCustomServers: boolean;
}>;
export declare type UtxoUserSettings = ReturnType<typeof asUtxoUserSettings>;
export interface UtxoTxOtherParams {
    unsignedTx: string;
    psbt?: {
        base64: string;
        inputs: Input[];
        outputs: Output[];
    };
    edgeSpendInfo?: EdgeSpendInfo;
    ourScriptPubkeys: string[];
    replacedTxid?: string;
}
export declare type UtxoSignMessageOtherParams = ReturnType<typeof asUtxoSignMessageOtherParams>;
export declare const asUtxoSignMessageOtherParams: import("cleaners").ObjectCleaner<{
    publicAddress: string;
}>;
export declare type UtxoSpendInfoOtherParams = ReturnType<typeof asUtxoSpendInfoOtherParams>;
export declare const asUtxoSpendInfoOtherParams: import("cleaners").ObjectCleaner<{
    enableRbf: boolean | undefined;
    forceChangeAddress: string | undefined;
    memoIndex: number | undefined;
    outputSort: "targets" | "bip69";
    txOptions: import("../../plugin/types").TxOptions | undefined;
    utxoSourceAddress: string | undefined;
}>;
