import { EdgeFetchFunction, EdgePaymentProtocolInfo, EdgeSpendTarget } from 'edge-core-js/types';
interface BitPayOutput {
    amount: number;
    address: string;
}
interface getSpendTargetsReturn {
    nativeAmount: number;
    spendTargets: EdgeSpendTarget[];
}
export declare function getSpendTargets(outputs: BitPayOutput[]): getSpendTargetsReturn;
export declare function getPaymentDetails(paymentProtocolURL: string, currencyCode: string, fetch: EdgeFetchFunction): Promise<EdgePaymentProtocolInfo>;
interface CreatePaymentReturn {
    currency: string;
    transactions: string[];
}
export declare function createPayment(tx: string, currencyCode: string): CreatePaymentReturn;
export declare function sendPayment(fetch: EdgeFetchFunction, paymentUrl: string, payment: unknown): Promise<any>;
export {};
