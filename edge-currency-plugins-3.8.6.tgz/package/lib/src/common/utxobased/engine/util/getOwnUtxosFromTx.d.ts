import { EngineInfo } from '../../../plugin/types';
import { DataLayer } from '../../db/DataLayer';
import { TransactionData, UtxoData } from '../../db/types';
export declare const getOwnUtxosFromTx: (engineInfo: EngineInfo, dataLayer: DataLayer, tx: TransactionData) => Promise<UtxoData[]>;
