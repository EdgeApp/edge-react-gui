import { Disklet } from 'disklet';
import { EdgeParsedUri } from 'edge-core-js/types';
import { ChangePath, CurrencyFormat, EngineInfo } from '../../plugin/types';
import { UtxoData } from '../db/types';
import { ScriptTemplates } from '../info/scriptTemplates/types';
import { PrivateKey } from '../keymanager/cleaners';
import { AddressTypeEnum, BIP43PurposeTypeEnum, ScriptTypeEnum } from '../keymanager/keymanager';
export declare const getCurrencyFormatFromPurposeType: (purpose: BIP43PurposeTypeEnum) => CurrencyFormat;
export declare const getAddressTypeFromPurposeType: (purpose: BIP43PurposeTypeEnum) => AddressTypeEnum;
export declare const getScriptTypeFromPurposeType: (purpose: BIP43PurposeTypeEnum) => ScriptTypeEnum;
export declare const validScriptPubkeyFromAddress: (args: {
    address: string;
    coin: string;
}) => string;
export declare const getFormatSupportedBranches: (engineInfo: EngineInfo, format: CurrencyFormat) => number[];
/**
 * The reason for this function is to consider the address path for
 * determining the purpose-type for the address. This is because some parts
 * of the address such as the changeIndex have special meaning for the
 * purpose-type. Specifically for scriptTemplates, the hash of the template
 * is used to deterministically identify the changeIndex used constantly for
 * the addresses spending to those scriptTemplates.
 *
 * In the future, we will want to strictly use only the format of the path
 * in order to determine the purpose-type per the BIP43 spec. This will require
 * a significant lift to reconsider the type for the path's format (currently
 * CurrencyFormat). The scriptTemplates could define a format index and this
 * could be used in address paths instead of a CurrencyType.
 */
export declare const pathToPurposeType: (path: ChangePath, scriptTemplates?: ScriptTemplates | undefined) => BIP43PurposeTypeEnum;
/**
 * Only use this function when needing to infer the purpose-type for a wallet
 * format (CurrencyFormat). To get the purpose-type for an address use
 * pathToPurposeType passing the address path.
 */
export declare const currencyFormatToPurposeType: (format: CurrencyFormat) => BIP43PurposeTypeEnum;
export declare type CurrencyFormatKeys = {
    [format in CurrencyFormat]?: string;
};
export declare const fetchOrDeriveXprivFromKeys: (args: {
    privateKey: PrivateKey;
    walletLocalEncryptedDisklet: Disklet;
    coin: string;
}) => Promise<CurrencyFormatKeys>;
export declare const deriveXprivFromKeys: (args: {
    privateKey: PrivateKey;
    coin: string;
}) => CurrencyFormatKeys;
export declare const deriveXpubsFromKeys: (args: {
    engineInfo: EngineInfo;
    privateKey: PrivateKey;
    coin: string;
}) => CurrencyFormatKeys;
export declare const parsePathname: (args: {
    pathname: string;
    coin: string;
}) => EdgeParsedUri;
export declare const sumUtxos: (utxos: UtxoData[]) => string;
