import { EdgeCurrencyEngine } from 'edge-core-js';
import { EngineConfig } from '../../plugin/types';
export declare function makeUtxoEngine(config: EngineConfig): Promise<EdgeCurrencyEngine>;
