export declare const BLOCKBOOK_TXS_PER_PAGE = 100;
export declare const CACHE_THROTTLE = 0.05;
export declare const MAX_CONNECTIONS = 2;
export declare const NEW_CONNECTIONS = 8;
