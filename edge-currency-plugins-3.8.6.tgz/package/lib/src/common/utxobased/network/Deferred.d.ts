export default class Deferred<T> {
    private _resolve;
    private _reject;
    private readonly _promise;
    get promise(): Promise<T>;
    resolve(value: T): void;
    reject(reason?: unknown): void;
}
