import { Cleaner } from 'cleaners';
import { EdgeLog } from 'edge-core-js/types';
import { EngineEmitter } from '../../plugin/EngineEmitter';
import { PluginInfo } from '../../plugin/types';
import { UtxoInitOptions } from '../engine/types';
import { Blockbook } from './Blockbook';
import { TaskGeneratorFn } from './Socket';
import { SocketEmitter } from './SocketEmitter';
export interface BlockbookElectrumConfig {
    asAddress?: Cleaner<string>;
    connectionUri: string;
    engineEmitter: EngineEmitter;
    initOptions: UtxoInitOptions;
    log: EdgeLog;
    taskGeneratorFn: TaskGeneratorFn;
    pluginInfo: PluginInfo;
    socketEmitter: SocketEmitter;
    walletId: string;
}
export interface ElectrumResponseMessage {
    id: number;
    data: unknown;
    error: {
        message: string;
    } | undefined;
}
export declare function makeBlockbookElectrum(config: BlockbookElectrumConfig): Blockbook;
