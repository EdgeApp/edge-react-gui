import { Cleaner } from 'cleaners';
/**
 * Websocket Task
 */
export interface BlockbookTask<T> {
    method: string;
    params: unknown;
    cleaner: Cleaner<T>;
}
export interface BlockbookAccountUtxo {
    txid: string;
    vout: number;
    value: string;
    confirmations?: number;
    coinbase?: boolean;
    height?: number;
    lockTime?: number;
    address?: string;
    path?: string;
}
export declare const asBlockbookAccountUtxo: (asAddress?: Cleaner<string>) => Cleaner<BlockbookAccountUtxo>;
export interface BlockbookTransaction {
    txid: string;
    hex: string;
    blockHeight: number;
    confirmations: number;
    blockTime: number;
    fees: string;
    vin: Array<{
        addresses: string[];
        isAddress?: boolean;
        n: number;
        sequence: number;
        txid?: string;
        value: string;
        vout: number;
        coinbase?: string;
        isOwn?: boolean;
        hex?: string;
        asm?: string;
    }>;
    vout: Array<{
        n: number;
        value: string;
        addresses: string[];
        hex?: string;
    }>;
}
export declare const asBlockbookTransaction: (asAddress?: Cleaner<string>) => Cleaner<BlockbookTransaction>;
/**
 * Error Response
 */
export declare type BlockbookErrorResponse = ReturnType<typeof asBlockbookErrorResponse>;
export declare const asBlockbookErrorResponse: import("cleaners").ObjectCleaner<{
    error: {
        message: any;
    };
}>;
/**
 * Blockbook Response Generic
 */
export declare type BlockbookResponse<T> = T;
export declare const asBlockbookResponse: <T>(asT: Cleaner<T>) => Cleaner<T>;
/**
 * Ping Message
 */
export declare const pingMessage: () => BlockbookTask<PingResponse>;
export declare type PingResponse = ReturnType<typeof asPingResponse>;
export declare const asPingResponse: import("cleaners").ObjectCleaner<object>;
/**
 * Get Info
 */
export declare const infoMessage: () => BlockbookTask<InfoResponse>;
export declare type InfoResponse = ReturnType<typeof asInfoResponse>;
export declare const asInfoResponse: import("cleaners").ObjectCleaner<{
    name: string;
    shortcut: string;
    decimals: number;
    version: string;
    bestHeight: number;
    bestHash: string;
    block0Hash: string;
    testnet: boolean;
    backend: {
        version: any;
        subversion: any;
    } | undefined;
}>;
/**
 * Get Account UTXO
 */
export declare const addressUtxosMessage: (address: string, asAddress?: Cleaner<string>) => BlockbookTask<AddressUtxosResponse>;
export declare type AddressUtxosResponse = BlockbookAccountUtxo[];
export declare const asAddressUtxosResponse: (asAddress?: Cleaner<string>) => Cleaner<AddressUtxosResponse>;
/**
 * Get Transaction
 */
export declare const transactionMessage: (hash: string, asAddress?: Cleaner<string>) => BlockbookTask<TransactionResponse>;
export declare type TransactionResponse = BlockbookTransaction;
export declare const asTransactionResponse: (asAddress?: Cleaner<string>) => Cleaner<BlockbookTransaction>;
/**
 * Get Transaction Specific
 */
export declare const transactionMessageSpecific: (hash: string) => BlockbookTask<unknown>;
/**
 * Send Transaction
 */
export declare const broadcastTxMessage: (signedTx: string) => BlockbookTask<BroadcastTxResponse>;
export declare type BroadcastTxResponse = ReturnType<typeof asBroadcastTxResponse>;
export declare const asBroadcastTxResponse: import("cleaners").ObjectCleaner<{
    result: string;
}>;
/**
 * Get Account Info
 */
export interface AddresssMessageParams {
    details?: 'basic' | 'txids' | 'txs';
    from?: number;
    to?: number;
    page?: number;
    pageSize?: number;
}
export declare const addressMessage: (address: string, asAddress?: Cleaner<string>, params?: AddresssMessageParams) => BlockbookTask<AddressResponse>;
export interface AddressResponse {
    address: string;
    balance: string;
    totalReceived: string;
    totalSent: string;
    txs: number;
    unconfirmedBalance: string;
    unconfirmedTxs: number;
    txids: string[];
    transactions: BlockbookTransaction[];
    page: number;
    totalPages: number;
    itemsOnPage: number;
}
export declare const asAddressResponse: (asAddress?: Cleaner<string>) => Cleaner<AddressResponse>;
/**
 * Subscribe New Block
 */
export declare const subscribeNewBlockMessage: () => BlockbookTask<SubscribeNewBlockResponse>;
export declare type SubscribeNewBlockResponse = ReturnType<typeof asSubscribeNewBlockResponse>;
export declare const asSubscribeNewBlockResponse: import("cleaners").ObjectCleaner<{
    height: number;
    hash: string;
}>;
/**
 * Subscribe Address
 */
export declare const subscribeAddressesMessage: (addresses: string[], asAddress?: Cleaner<string>) => BlockbookTask<SubscribeAddressResponse>;
export interface SubscribeAddressResponse {
    address: string;
    tx: BlockbookTransaction;
}
export declare const asSubscribeAddressResponse: (asAddress?: Cleaner<string>) => Cleaner<SubscribeAddressResponse>;
