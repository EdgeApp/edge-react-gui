export interface InnerSocketCallbacks {
    /**
     * Called when the socket closes.
     * See rfc6455 section 7.4.1 for status codes.
     */
    onClose: (code: number, reason: string) => void;
    onError: (error?: Event | Error) => void;
    onMessage: (message: string) => void;
    onOpen: () => void;
}
export declare enum ReadyState {
    CONNECTING = 0,
    OPEN = 1,
    CLOSING = 2,
    CLOSED = 3
}
export interface InnerSocket {
    readyState: ReadyState;
    disconnect: () => void;
    send: (message: string) => void;
}
