import { DataLayer } from '../DataLayer';
import { TransactionData, UtxoData } from '../types';
export declare const utxoFromTransactionDataInput: (dataLayer: DataLayer, transactionData: TransactionData, inputIndex: number) => Promise<UtxoData>;
