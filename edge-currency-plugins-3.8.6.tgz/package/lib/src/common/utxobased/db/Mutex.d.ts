declare type Mutex = <T>(callback: () => Promise<T>) => Promise<T>;
export declare function makeMutex(): Mutex;
export {};
