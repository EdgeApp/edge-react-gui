import { Cleaner } from 'cleaners';
import { CurrencyFormat, EngineInfo, PluginInfo } from '../../plugin/types';
declare type PrivateKeyFormat = ReturnType<typeof asPrivateKeyFormat>;
declare const asPrivateKeyFormat: Cleaner<"bip32" | "bip44" | "bip49">;
/**
 * A cleaner for the private key format following the key-formats specification.
 * It _includes_ the private key.
 *
 * **It is not considered safe memory, and it should be deallocated
 * (thrown away) after use**.
 *
 * (spec: https://github.com/EdgeApp/edge-core-js/blob/master/docs/key-formats.md)
 */
export interface PrivateKey {
    coinType: number;
    format: PrivateKeyFormat;
    imported?: boolean;
    seed: string;
}
export declare function asPrivateKey(coinName: string, coinType?: number): Cleaner<PrivateKey>;
/**
 * A cleaner for the public key format following the key-formats specification.
 *
 * (spec: https://github.com/EdgeApp/edge-core-js/blob/master/docs/key-formats.md)
 */
export interface PublicKey {
    publicKeys: {
        [format in CurrencyFormat]?: string;
    };
}
export declare const asPublicKey: Cleaner<PublicKey>;
/**
 * This utility returns a wallet's supported formats according to its
 * private-key's format as specified in the key-formats specification.
 */
export declare const getSupportedFormats: (engineInfo: EngineInfo, privateKeyFormat: PrivateKeyFormat) => CurrencyFormat[];
/**
 * Infers the private key format given a public key
 */
export declare const inferPrivateKeyFormat: (publicKey: PublicKey) => PrivateKeyFormat;
/**
 * A cleaner that desensitizes an unsafeWalletInfo object, excluding sensitive
 * keys (seed/mnemonic, sync key, data key, etc). By using this object type
 * internally within the plugin, we can minimize risk of leaking sensitive data
 * when deriving public keys from walletInfo which only contains private keys.
 * It may also be used on a safeWalletInfo object which only contains the
 * wallet's public keys.
 *
 * It also includes internal derived data (publicKey, format, walletFormats, etc).
 * This derived data is to be used internally within the plugin and saved to disk (publicKey).
 *
 * The `walletFormats` field is a list of formats from which to derive
 * extended-keys for the wallet.
 *
 * The `privateKeyFormat` field is the format defined by the private key and is
 * useful for determining the "kind of wallet", or more precisely how the public
 * key (xpubs) formats were derived.
 */
export interface SafeWalletInfo {
    id: string;
    type: string;
    keys: {
        imported?: boolean;
        privateKeyFormat: PrivateKeyFormat;
        publicKey: PublicKey;
        walletFormats: CurrencyFormat[];
    };
}
export declare const asSafeWalletInfo: (pluginInfo: PluginInfo) => Cleaner<SafeWalletInfo>;
export {};
