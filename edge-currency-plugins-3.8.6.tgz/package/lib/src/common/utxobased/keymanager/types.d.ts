import { Cleaner } from 'cleaners';
import { EdgeTokenId, InsufficientFundsError } from 'edge-core-js/types';
interface InsufficientFundsErrorOptsPlus {
    tokenId: EdgeTokenId;
    networkFee?: string;
    networkFeeShortage?: string;
}
export declare class InsufficientFundsErrorPlus extends InsufficientFundsError {
    networkFeeShortage?: string;
    constructor(opts: InsufficientFundsErrorOptsPlus);
}
export declare const asMaybeInsufficientFundsErrorPlus: Cleaner<InsufficientFundsErrorPlus | undefined>;
export {};
