/// <reference types="node" />
import { Buffer } from 'buffer';
interface Base58BaseReturn {
    encode: (payload: Buffer) => string;
    decode: (stringPayload: string | undefined) => Buffer;
    decodeUnsafe: (stringPayload: string) => Buffer | undefined;
}
export declare function base58Base(checksumFn: (buffer: Buffer) => Buffer): Base58BaseReturn;
export {};
