import { UtxoPickerArgs, UtxoPickerResult } from './types';
export declare function subtractFee(args: UtxoPickerArgs): UtxoPickerResult;
