import { UtxoPickerArgs, UtxoPickerResult } from './types';
export declare function forceUseUtxo(args: UtxoPickerArgs): UtxoPickerResult;
