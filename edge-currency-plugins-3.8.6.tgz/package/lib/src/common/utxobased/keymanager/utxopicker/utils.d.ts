import { Input, Output, UTXO, UtxoPickerResult } from './types';
export declare const compactSize: (num: number) => number;
export declare const withCompactSize: (num: number) => number;
export declare function inputBytes(input: UTXO): number;
export declare function outputBytes(output: Output): number;
export declare function dustThreshold(output: Output, feeRate: number): number;
export declare function transactionBytes(inputs: UTXO[], outputs: Output[]): number;
export declare const transactionSizeFromHex: (hex: string) => number;
export declare function uintOrNaN(v: number): number;
export declare function sumForgiving(range: Array<{
    value: number;
}>): number;
export declare function sumOrNaN(range: Array<{
    value: number;
}>): number;
export declare function finalize(inputs: Input[], outputs: Output[], feeRate: number, changeScript: string): UtxoPickerResult;
