import { UtxoPickerArgs, UtxoPickerResult } from './types';
export declare function accumulative(args: UtxoPickerArgs): UtxoPickerResult;
