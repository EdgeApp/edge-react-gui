import { Disklet } from 'disklet';
import { EdgeIo, EdgeLog, EdgeSpendInfo } from 'edge-core-js/types';
import { FeeInfo, PluginInfo } from '../plugin/types';
interface MakeFeesConfig extends Common {
    disklet: Disklet;
    pluginInfo: PluginInfo;
}
interface Common {
    io: EdgeIo;
    log: EdgeLog;
}
export interface Fees {
    start: () => Promise<void>;
    stop: () => void;
    clearCache: () => Promise<void>;
    getRate: (edgeSpendInfo: EdgeSpendInfo) => Promise<string>;
    feeInfo: FeeInfo;
}
export declare const makeFees: (config: MakeFeesConfig) => Promise<Fees>;
export {};
