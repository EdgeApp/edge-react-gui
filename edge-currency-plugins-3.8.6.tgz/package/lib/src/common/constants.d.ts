export declare const INFO_SERVER_URI = "https://info1.edge.app";
export declare const FEES_PATH = "fees.json";
export declare const MAX_FEE = 999999999;
export declare const LOW_FEE = 2;
export declare const MAX_HIGH_DELAY = 200;
export declare const MAX_STANDARD_DELAY = 6;
export declare const MIN_STANDARD_DELAY = 2;
export declare const MIN_LOW_DELAY = 1;
