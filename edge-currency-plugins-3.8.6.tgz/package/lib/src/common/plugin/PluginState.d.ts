import { Disklet } from 'disklet';
import { EdgeIo, EdgeLog } from 'edge-core-js/types';
import { UtxoUserSettings } from '../utxobased/engine/types';
import { UtxoEngineProcessor } from '../utxobased/engine/UtxoEngineProcessor';
import { InfoPayload } from './types';
/** A JSON object (as opposed to an array or primitive). */
interface JsonObject {
    [name: string]: unknown;
}
/**
 * This object holds the plugin-wide per-currency caches.
 * Engine plugins are responsible for keeping it up to date.
 */
export interface PluginStateSettings {
    currencyCode: string;
    defaultSettings: UtxoUserSettings;
    infoPayload: InfoPayload | undefined;
    io: EdgeIo;
    log: EdgeLog;
    pluginDisklet: Disklet;
    pluginId: string;
}
export interface PluginState {
    infoPayload: InfoPayload | undefined;
    addEngine: (engineProcessor: UtxoEngineProcessor) => void;
    removeEngine: (engineProcessor: UtxoEngineProcessor) => void;
    dumpData: () => JsonObject;
    load: () => Promise<PluginState>;
    serverScoreDown: (uri: string) => void;
    serverScoreUp: (uri: string, score: number) => void;
    clearCache: () => Promise<void>;
    getLocalServers: (numServersWanted: number, includePatterns?: Array<string | RegExp>) => string[];
    refreshServers: (updatedCustomServers?: string[]) => Promise<void>;
    updateServers: (settings: UtxoUserSettings) => Promise<void>;
}
export declare function makePluginState(settings: PluginStateSettings): PluginState;
export {};
