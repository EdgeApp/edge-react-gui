import { Disklet } from 'disklet';
import { EdgeLog } from 'edge-core-js/types';
import { EngineEmitter } from './EngineEmitter';
import { LocalWalletMetadata } from './types';
interface MetadataConfig {
    disklet: Disklet;
    emitter: EngineEmitter;
    log: EdgeLog;
}
export interface Metadata {
    state: LocalWalletMetadata;
    clear: () => Promise<void>;
}
export declare const makeMetadata: (config: MetadataConfig) => Promise<Metadata>;
export {};
