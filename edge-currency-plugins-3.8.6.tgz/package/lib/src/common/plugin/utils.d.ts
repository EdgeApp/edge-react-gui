export declare const getFormatsForNetwork: (coinName: string) => string[];
interface GenericObject<T> {
    [key: string]: T;
}
export declare const removeItem: <T>(obj: GenericObject<T>, key: string) => void;
export {};
