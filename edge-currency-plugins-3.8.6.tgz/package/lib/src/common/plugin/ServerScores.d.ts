import { EdgeLog } from 'edge-core-js/types';
export declare type ServerInfo = ReturnType<typeof asServerInfo>;
export declare const asServerInfo: import("cleaners").ObjectCleaner<{
    serverUrl: string;
    serverScore: number;
    responseTime: number;
    numResponseTimes: number;
}>;
export declare type ServerList = ReturnType<typeof asServerList>;
export declare const asServerList: import("cleaners").Cleaner<{
    [keys: string]: {
        serverUrl: string;
        serverScore: number;
        responseTime: number;
        numResponseTimes: number;
    };
}>;
export declare type ServerCache = ReturnType<typeof asServerCache>;
export declare const asServerCache: import("cleaners").ObjectCleaner<{
    customServers: {
        [keys: string]: {
            serverUrl: any;
            serverScore: any;
            responseTime: any;
            numResponseTimes: any;
        };
    };
    enableCustomServers: boolean;
    internalServers: {
        [keys: string]: {
            serverUrl: any;
            serverScore: any;
            responseTime: any;
            numResponseTimes: any;
        };
    };
}>;
interface ServerScoresOptions {
    log: EdgeLog;
    onDirtyServer?: (serverUrl: string) => void;
}
export declare class ServerScores {
    scoresLastLoaded: number;
    log: EdgeLog;
    lastScoreUpTime: number;
    onDirtyServer: (serverUrl: string) => void;
    constructor(options: ServerScoresOptions);
    /**
     * Loads the server scores with new and old servers, mutates the passed in
     * list of known servers.
     * @param knownServers: Map of ServerInfo objects by serverUrl. This should come from disk
     * @param newServers: Array<string> of new servers downloaded from the info server
     */
    serverScoresLoad(knownServers: ServerList, newServers?: string[]): void;
    clearServerScoreTimes(): void;
    printServers(servers: ServerList): void;
    serverScoreUp(servers: ServerList, serverUrl: string, responseTimeMilliseconds: number, changeScore?: number): void;
    serverScoreDown(servers: ServerList, serverUrl: string, changeScore?: number): void;
    setResponseTime(servers: ServerList, serverUrl: string, responseTimeMilliseconds: number): void;
    getServers(servers: ServerList, numServersWanted: number, includePatterns?: Array<string | RegExp>): string[];
    removeServers(servers: ServerList, serverUrls: string[]): void;
}
export {};
