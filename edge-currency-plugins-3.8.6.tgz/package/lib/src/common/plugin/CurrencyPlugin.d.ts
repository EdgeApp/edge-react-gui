import { EdgeCorePluginOptions, EdgeCurrencyPlugin } from 'edge-core-js/types';
import { PluginInfo } from './types';
export declare function makeCurrencyPlugin(pluginOptions: EdgeCorePluginOptions, pluginInfo: PluginInfo): EdgeCurrencyPlugin;
